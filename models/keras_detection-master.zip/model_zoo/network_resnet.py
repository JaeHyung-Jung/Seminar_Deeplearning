from tensorflow.keras.layers import *
from tensorflow.keras.models import Model

from . import network_base


# Make blocks
def identity_res_block(input_tensor, kernel_size, filters, stage, block):
    filters1, filters2, filters3 = filters
    conv_name_base = 'res' + str(stage) + '_' + str(block) + '_branch'
    bn_name_base = 'bn' + str(stage) + '_' + str(block) + '_branch'

    x = Conv2D(filters1, (1, 1), kernel_initializer='he_normal', name=conv_name_base + '2a')(input_tensor)
    x = BatchNormalization(name=bn_name_base + '2a')(x)
    x = Activation('relu')(x)

    x = Conv2D(filters2, kernel_size, padding='same', kernel_initializer='he_normal', name=conv_name_base + '2b')(x)
    x = BatchNormalization(name=bn_name_base + '2b')(x)
    x = Activation('relu')(x)

    x = Conv2D(filters3, (1, 1), kernel_initializer='he_normal', name=conv_name_base + '2c')(x)
    x = BatchNormalization(name=bn_name_base + '2c')(x)

    x = add([x, input_tensor])
    x = Activation('relu')(x)
    return x


def conv_res_block(input_tensor, kernel_size, filters, stage, block, strides=(2, 2)):
    filters1, filters2, filters3 = filters
    conv_name_base = 'res' + str(stage) + '_' + str(block) + '_branch'
    bn_name_base = 'bn' + str(stage) + '_' + str(block) + '_branch'

    x = Conv2D(filters1, (1, 1), kernel_initializer='he_normal', name=conv_name_base + '2a')(input_tensor)
    x = BatchNormalization(name=bn_name_base + '2a')(x)
    x = Activation('relu')(x)

    x = Conv2D(filters2, kernel_size, kernel_initializer='he_normal', padding='same', name=conv_name_base + '2b')(x)
    x = BatchNormalization(name=bn_name_base + '2b')(x)
    x = Activation('relu')(x)

    x = Conv2D(filters3, kernel_size, kernel_initializer='he_normal', padding='same', name=conv_name_base + '2c')(x)
    x = BatchNormalization(name=bn_name_base + '2c')(x)
    x = Activation('relu')(x)

    shortcut = Conv2D(filters3, (1, 1), strides=strides, kernel_initializer='he_normal',
                      name=conv_name_base + '1')(input_tensor)
    shortcut = BatchNormalization(name=bn_name_base + '1')(shortcut)

    x = add([x, shortcut])
    x = Activation('relu')(x)

    return x


# Make Stages
def stem_stage_layer(x):
    """No Residual Blocks"""
    x = MaxPool2D((3, 3), strides=2)(x)  # 임의로 설정
    x = ZeroPadding2D(padding=(3, 3))(x)
    x = Conv2D(64, (7, 7), strides=(2, 2))(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = ZeroPadding2D(padding=(1, 1))(x)
    x = MaxPooling2D((3, 3), 2)(x)
    return x


def stage_layer(x, n_stage, channel, n_loop):
    """
    x : input_tensor, n_stage = n-th stage(n>1), channel : (a, a, 4a) channels, n_loop = # loops
    """
    # 1 loop : conv_block, n-1 loop: identity_block
    loops = range(1, n_loop)
    x = conv_res_block(x, 3, [channel, channel, 4 * channel], stage=n_stage, block=0, strides=(1, 1))
    for loop in loops:
        x = identity_res_block(x, 3, [channel, channel, 4 * channel], stage=n_stage, block=loop)
    return x


class ResnetNetwork(network_base.BaseNetwork):
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling=None, classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)

    def setup(self):
        img_input = self.get_input_tensor()
        x = stem_stage_layer(img_input)
        x = stage_layer(x, n_stage=2, channel=64, n_loop=3)
        x = stage_layer(x, n_stage=3, channel=128, n_loop=4)
        x = stage_layer(x, n_stage=4, channel=256, n_loop=6)
        x = stage_layer(x, n_stage=5, channel=512, n_loop=3)
        x = self.get_pool(x)

        if self.include_top:
            x = self.get_top_include(x)
            model = Model(img_input, x, name='Resnet50-v1')
            return model
        else:
            return x
