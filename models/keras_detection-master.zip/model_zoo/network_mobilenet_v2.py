"""
Readme :
    It focuses on "tf.Keras" Version (tf. 2.3.0)
    It's slightly different other architecture.
    If you have a question, feel free to ask.
    Note : Alpha values have " 0.35, 0.5, 0.75, 1.0, 1.3 and
"""
from tensorflow.keras.layers import *
from tensorflow.keras.models import Model
from tensorflow.keras import backend as K

from . import network_base


def correct_pad(inputs, kernel_size):
    """Returns a tuple for zero-padding for 2D convolution with downsampling.

    Arguments:
    inputs: Input tensor.
    kernel_size: An integer or tuple/list of 2 integers.

    Returns:
    A tuple.
    """
    img_dim = 2 if K.image_data_format() == 'channels_first' else 1
    input_size = K.int_shape(inputs)[img_dim:(img_dim + 2)]
    if isinstance(kernel_size, int):
        kernel_size = (kernel_size, kernel_size)
    if input_size[0] is None:
        adjust = (1, 1)
    else:
        adjust = (1 - input_size[0] % 2, 1 - input_size[1] % 2)
    correct = (kernel_size[0] // 2, kernel_size[1] // 2)
    return ((correct[0] - adjust[0], correct[0]),
            (correct[1] - adjust[1], correct[1]))


def make_divisible(v, divisor, min_value=None):
    if min_value is None:
        min_value = divisor
    new_v = max(min_value, int(v + divisor / 2) // divisor * divisor)
    # Make sure that round down does not go down by more than 10%.
    if new_v < 0.9 * v:
        new_v += divisor
    return new_v


def stem_conv_block(x, alpha):
    first_block_filters = make_divisible(32 * alpha, 8)
    x = ZeroPadding2D(padding=correct_pad(x, (3, 3)), name='Conv1_pad')(x)
    x = Conv2D(first_block_filters, (3, 3), strides=2, padding='valid', use_bias=False, name='Conv1')(x)
    x = BatchNormalization(axis=3, epsilon=1e-3, momentum=0.999, name='bn_Conv1')(x)
    x = ReLU(6., name='Conv1_relu')(x)
    return x


def inverted_res_block(inputs, expansion, stride, alpha, channels, block_id=1):
    pointwise_conv_channels = int(channels * alpha)
    in_channels = K.int_shape(inputs)[3]  # 3 means channels
    pointwise_filters = make_divisible(pointwise_conv_channels, 8)
    x = inputs
    prefix = 'block_{}_'.format(block_id)
    if block_id:
        x = Conv2D(expansion * in_channels, (1, 1), padding='same', use_bias=False,
                   activation=None, name=prefix + 'expand')(x)
        x = BatchNormalization(axis=3, epsilon=1e-3, momentum=0.999, name=prefix + 'expand_BN')(x)
        x = ReLU(6., name=prefix + 'expand_relu')(x)
    else:
        prefix = 'expanded_conv_'

    if stride == 2:
        x = ZeroPadding2D(padding=correct_pad(x, (3, 3)), name=prefix + 'pad')(x)
    x = DepthwiseConv2D(kernel_size=3, strides=stride, activation=None, use_bias=False,
                        padding='same' if stride == 1 else 'valid', name=prefix+'depthwise')(x)
    x = BatchNormalization(axis=3, epsilon=1e-3, momentum=0.999, name=prefix + 'depthwise_BN')(x)
    x = ReLU(6., name=prefix + 'depthwise_relu')(x)

    x = Conv2D(pointwise_filters, (1, 1), padding='same', use_bias=False, activation=None,
               name=prefix + 'project')(x)
    x = BatchNormalization(axis=3, epsilon=1e-3, momentum=0.999, name=prefix + 'project_BN')(x)
    if in_channels == pointwise_filters and stride == 1:
        return Add(name=prefix + 'add')([inputs, x])
    return x


class Mobilenet_v2_Network(network_base.BaseNetwork):
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling='avg', classes=2,
                 alpha=1, depth_multiplier=1):
        self.alpha = alpha
        self.depth_multiplier = depth_multiplier
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)

    def setup(self):
        filters = [16, 24, 24, 32, 32, 32, 64, 64, 64, 64, 96, 96, 96, 160, 160, 160, 320]
        strides = [1, 2, 1, 2, 1, 1, 2, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1]
        expands = [1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6]

        # structures
        img_input = self.get_input_tensor()
        x = stem_conv_block(img_input, alpha=1)
        for idx, (i, j, k) in enumerate(zip(filters, strides, expands)):  # about 17 layers
            x = inverted_res_block(x, expansion=k, stride=j, alpha=self.alpha, channels=i, block_id=idx)

        if self.alpha > 1.0:
            last_block_filters = make_divisible(1280 * self.alpha, 8)
        else:
            last_block_filters = 1280

        x = Conv2D(last_block_filters, kernel_size=(1, 1), use_bias=False, name='Conv_1')(x)
        x = BatchNormalization(axis=3, epsilon=1e-3, momentum=0.999, name='Conv1_bn')(x)
        x = ReLU(6., name='out_relu')(x)

        # output
        x = self.get_pool(x)  # Global avg
        if self.include_top:
            x = self.get_top_include(x)
            model = Model(img_input, x, name='Mobilenet_v1')
            return model
        else:
            return x
