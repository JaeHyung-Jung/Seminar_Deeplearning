from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from tensorflow.keras.layers import *
from tensorflow.python.keras import backend as K
from tensorflow.keras import Model
from . import network_base

import copy
import math

from tensorflow.python.keras.applications import imagenet_utils


BASE_WEIGHTS_PATH = 'https://storage.googleapis.com/keras-applications/'

WEIGHTS_HASHES = {
    'b0': ('902e53a9f72be733fc0bcb005b3ebbac',
           '50bc09e76180e00e4465e1a485ddc09d'),
    'b1': ('1d254153d4ab51201f1646940f018540',
           '74c4e6b3e1f6a1eea24c589628592432'),
    'b2': ('b15cce36ff4dcbd00b6dd88e7857a6ad',
           '111f8e2ac8aa800a7a99e3239f7bfb39'),
    'b3': ('ffd1fdc53d0ce67064dc6a9c7960ede0',
           'af6d107764bb5b1abb91932881670226'),
    'b4': ('18c95ad55216b8f92d7e70b3a046e2fc',
           'ebc24e6d6c33eaebbd558eafbeedf1ba'),
    'b5': ('ace28f2a6363774853a83a0b21b9421a',
           '38879255a25d3c92d5e44e04ae6cec6f'),
    'b6': ('165f6e37dce68623721b423839de8be5',
           '9ecce42647a20130c1f39a5d4cb75743'),
    'b7': ('8c03f828fec3ef71311cd463b6759d99',
           'cbcfe4450ddf6f3ad90b1b398090fe4a'),
}

DEFAULT_BLOCKS_ARGS = [{
    'kernel_size': 3,
    'repeats': 1,
    'filters_in': 32,
    'filters_out': 16,
    'expand_ratio': 1,
    'id_skip': True,
    'strides': 1,
    'se_ratio': 0.25
}, {
    'kernel_size': 3,
    'repeats': 2,
    'filters_in': 16,
    'filters_out': 24,
    'expand_ratio': 6,
    'id_skip': True,
    'strides': 2,
    'se_ratio': 0.25
}, {
    'kernel_size': 5,
    'repeats': 2,
    'filters_in': 24,
    'filters_out': 40,
    'expand_ratio': 6,
    'id_skip': True,
    'strides': 2,
    'se_ratio': 0.25
}, {
    'kernel_size': 3,
    'repeats': 3,
    'filters_in': 40,
    'filters_out': 80,
    'expand_ratio': 6,
    'id_skip': True,
    'strides': 2,
    'se_ratio': 0.25
}, {
    'kernel_size': 5,
    'repeats': 3,
    'filters_in': 80,
    'filters_out': 112,
    'expand_ratio': 6,
    'id_skip': True,
    'strides': 1,
    'se_ratio': 0.25
}, {
    'kernel_size': 5,
    'repeats': 4,
    'filters_in': 112,
    'filters_out': 192,
    'expand_ratio': 6,
    'id_skip': True,
    'strides': 2,
    'se_ratio': 0.25
}, {
    'kernel_size': 3,
    'repeats': 1,
    'filters_in': 192,
    'filters_out': 320,
    'expand_ratio': 6,
    'id_skip': True,
    'strides': 1,
    'se_ratio': 0.25
}]

CONV_KERNEL_INITIALIZER = {
    'class_name': 'VarianceScaling',
    'config': {
        'scale': 2.0,
        'mode': 'fan_out',
        'distribution': 'truncated_normal'
    }
}

DENSE_KERNEL_INITIALIZER = {
    'class_name': 'VarianceScaling',
    'config': {
        'scale': 1. / 3.,
        'mode': 'fan_out',
        'distribution': 'uniform'
    }
}


def block(inputs, activation='swish', drop_rate=0., name='', filters_in=32, filters_out=16,
          kernel_size=3, strides=1, expand_ratio=1, se_ratio=0., id_skip=True):
    bn_axis = 3 if K.image_data_format() == 'channels_last' else 1

    # Expansion phase
    filters = filters_in * expand_ratio
    if expand_ratio != 1:
        x = Conv2D(filters, 1, padding='same', use_bias=False, kernel_initializer=CONV_KERNEL_INITIALIZER,
                   name=name + 'expand_conv')(inputs)
        x = BatchNormalization(axis=bn_axis, name=name + 'expand_bn')(x)
        x = Activation(activation, name=name + 'expand_activation')(x)
    else:
        x = inputs

    # Depthwise Convolution
    if strides == 2:
        x = ZeroPadding2D(padding=imagenet_utils.correct_pad(x, kernel_size), name=name + 'dwconv_pad')(x)
        conv_pad = 'valid'
    else:
        conv_pad = 'same'
    x = DepthwiseConv2D(kernel_size, strides=strides, padding=conv_pad, use_bias=False,
                        depthwise_initializer=CONV_KERNEL_INITIALIZER, name=name + 'dwconv')(x)
    x = BatchNormalization(axis=bn_axis, name=name + 'bn')(x)
    x = Activation(activation, name=name + 'activation')(x)

    # Squeeze and Excitation phase
    if 0 < se_ratio <= 1:
        filters_se = max(1, int(filters_in * se_ratio))
        se = GlobalAveragePooling2D(name=name + 'se_squeeze')(x)
        se = Reshape((1, 1, filters), name=name + 'se_reshape')(se)
        se = Conv2D(filters_se, 1, padding='same', activation=activation, kernel_initializer=CONV_KERNEL_INITIALIZER,
                    name=name + 'se_reduce')(se)
        se = Conv2D(filters, 1, padding='same', activation='sigmoid', kernel_initializer=CONV_KERNEL_INITIALIZER,
                    name=name + 'se_expand')(se)
        x = multiply([x, se], name=name + 'se_excite')

    # Output phase
    x = Conv2D(filters_out, 1, padding='same', use_bias=False,
               kernel_initializer=CONV_KERNEL_INITIALIZER, name=name + 'project_conv')(x)
    x = BatchNormalization(axis=bn_axis, name=name + 'project_bn')(x)
    if id_skip and strides == 1 and filters_in == filters_out:
        if drop_rate > 0:
            x = Dropout(drop_rate, noise_shape=(None, 1, 1, 1), name=name + 'drop')(x)
        x = add([x, inputs], name=name + 'add')
    return x


class EfficientNetBaseNetwork(network_base.BaseNetwork):
    def __init__(self, width_coefficient, depth_coefficient, default_size, dropout_rate=0.2, drop_connect_rate=0.2,
                 depth_divisor=8, activation='swish', blocks_args='default', model_name='efficientnet',
                 include_top=True, input_tensor=None, input_shape=None, pooling='avg', classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)
        self.width_coefficient = width_coefficient
        self.depth_coefficient = depth_coefficient
        self.default_size = default_size
        self.dropout_rate = dropout_rate
        self.drop_connect_rate = drop_connect_rate
        self.depth_divisor = depth_divisor
        self.activation = activation
        self.blocks_args = blocks_args
        self.model_name = model_name

    def setup(self):
        bn_axis = 3 if K.image_data_format() == 'channels_last' else 1
        if self.blocks_args == 'default':
            pass
        blocks_args = DEFAULT_BLOCKS_ARGS

        def round_filters(filters, divisor=self.depth_divisor):
            """Round number of filters based on depth multiplier."""
            filters *= self.width_coefficient
            new_filters = max(divisor, int(filters + divisor / 2) // divisor * divisor)
            # Make sure that round down does not go down by more than 10%.
            if new_filters < 0.9 * filters:
                new_filters += divisor
            return int(new_filters)

        def round_repeats(repeats):
            """Round number of repeats based on depth multiplier."""
            return int(math.ceil(self.depth_coefficient * repeats))

        img_input = self.get_input_tensor()
        # Build stem
        x = img_input
        x = Lambda(lambda w: w * 1. / 255.)(x)
        x = BatchNormalization(axis=bn_axis)(x)
        x = ZeroPadding2D(padding=imagenet_utils.correct_pad(x, 3), name='stem_conv_pad')(x)
        x = Conv2D(round_filters(32), 3, strides=2, padding='valid', use_bias=False,
                   kernel_initializer=CONV_KERNEL_INITIALIZER, name='stem_conv')(x)
        x = BatchNormalization(axis=bn_axis, name='stem_bn')(x)
        x = Activation(self.activation, name='stem_activation')(x)

        # Build blocks
        blocks_args = copy.deepcopy(blocks_args)

        b = 0
        blocks = float(sum(round_repeats(args['repeats']) for args in blocks_args))
        for (i, args) in enumerate(blocks_args):
            assert args['repeats'] > 0
            # Update block input and output filters based on depth multiplier.
            args['filters_in'] = round_filters(args['filters_in'])
            args['filters_out'] = round_filters(args['filters_out'])

            for j in range(round_repeats(args.pop('repeats'))):
                # The first block needs to take care of stride and filter size increase.
                if j > 0:
                    args['strides'] = 1
                    args['filters_in'] = args['filters_out']
                x = block(x, self.activation, self.drop_connect_rate * b / blocks,
                          name='block{}{}_'.format(i + 1, chr(j + 97)), **args)
                b += 1

        # Build top
        x = Conv2D(round_filters(1280), 1, padding='same', use_bias=False,
                   kernel_initializer=CONV_KERNEL_INITIALIZER, name='top_conv')(x)
        x = BatchNormalization(axis=bn_axis, name='top_bn')(x)
        x = Activation(self.activation, name='top_activation')(x)
        x = self.get_pool(x)
        if self.include_top:
            if self.dropout_rate > 0:
                x = Dropout(self.dropout_rate, name='top_dropout')(x)
                x = Dense(self.classes, activation='softmax',
                          kernel_initializer=DENSE_KERNEL_INITIALIZER, name='predictions')(x)
        # Create model.
            model = Model(img_input, x, name=self.model_name)
            return model
        else:
            return x


class EfficientNetB0_Network(EfficientNetBaseNetwork):
    def __init__(self, width_coefficient=1.0, depth_coefficient=1.0, default_size=224, dropout_rate=0.2,
                 drop_connect_rate=0.2, depth_divisor=8, activation='swish', blocks_args='default',
                 model_name='efficientnet_B0', include_top=True, input_tensor=None, input_shape=None, pooling='avg',
                 classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)
        self.width_coefficient = width_coefficient
        self.depth_coefficient = depth_coefficient
        self.default_size = default_size
        self.dropout_rate = dropout_rate
        self.drop_connect_rate = drop_connect_rate
        self.depth_divisor = depth_divisor
        self.activation = activation
        self.blocks_args = blocks_args
        self.model_name = model_name


class EfficientNetB1_Network(EfficientNetBaseNetwork):
    def __init__(self, width_coefficient=1.0, depth_coefficient=1.1, default_size=240, dropout_rate=0.2,
                 drop_connect_rate=0.2, depth_divisor=8, activation='swish', blocks_args='default',
                 model_name='efficientnet_B1', include_top=True, input_tensor=None, input_shape=None, pooling='avg',
                 classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)
        self.width_coefficient = width_coefficient
        self.depth_coefficient = depth_coefficient
        self.default_size = default_size
        self.dropout_rate = dropout_rate
        self.drop_connect_rate = drop_connect_rate
        self.depth_divisor = depth_divisor
        self.activation = activation
        self.blocks_args = blocks_args
        self.model_name = model_name


class EfficientNetB2_Network(EfficientNetBaseNetwork):
    def __init__(self, width_coefficient=1.1, depth_coefficient=1.2, default_size=260, dropout_rate=0.3,
                 drop_connect_rate=0.2, depth_divisor=8, activation='swish', blocks_args='default',
                 model_name='efficientnet_B2', include_top=True, input_tensor=None, input_shape=None, pooling='avg',
                 classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)
        self.width_coefficient = width_coefficient
        self.depth_coefficient = depth_coefficient
        self.default_size = default_size
        self.dropout_rate = dropout_rate
        self.drop_connect_rate = drop_connect_rate
        self.depth_divisor = depth_divisor
        self.activation = activation
        self.blocks_args = blocks_args
        self.model_name = model_name


class EfficientNetB3_Network(EfficientNetBaseNetwork):
    def __init__(self, width_coefficient=1.2, depth_coefficient=1.4, default_size=300, dropout_rate=0.3,
                 drop_connect_rate=0.2, depth_divisor=8, activation='swish', blocks_args='default',
                 model_name='efficientnet_B3', include_top=True, input_tensor=None, input_shape=None, pooling='avg',
                 classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)
        self.width_coefficient = width_coefficient
        self.depth_coefficient = depth_coefficient
        self.default_size = default_size
        self.dropout_rate = dropout_rate
        self.drop_connect_rate = drop_connect_rate
        self.depth_divisor = depth_divisor
        self.activation = activation
        self.blocks_args = blocks_args
        self.model_name = model_name


class EfficientNetB4_Network(EfficientNetBaseNetwork):
    def __init__(self, width_coefficient=1.4, depth_coefficient=1.8, default_size=380, dropout_rate=0.4,
                 drop_connect_rate=0.2, depth_divisor=8, activation='swish', blocks_args='default',
                 model_name='efficientnet_B4', include_top=True, input_tensor=None, input_shape=None, pooling='avg',
                 classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)
        self.width_coefficient = width_coefficient
        self.depth_coefficient = depth_coefficient
        self.default_size = default_size
        self.dropout_rate = dropout_rate
        self.drop_connect_rate = drop_connect_rate
        self.depth_divisor = depth_divisor
        self.activation = activation
        self.blocks_args = blocks_args
        self.model_name = model_name


class EfficientNetB5_Network(EfficientNetBaseNetwork):
    def __init__(self, width_coefficient=1.6, depth_coefficient=2.2, default_size=456, dropout_rate=0.4,
                 drop_connect_rate=0.2, depth_divisor=8, activation='swish', blocks_args='default',
                 model_name='efficientnet_B5', include_top=True, input_tensor=None, input_shape=None, pooling='avg',
                 classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)
        self.width_coefficient = width_coefficient
        self.depth_coefficient = depth_coefficient
        self.default_size = default_size
        self.dropout_rate = dropout_rate
        self.drop_connect_rate = drop_connect_rate
        self.depth_divisor = depth_divisor
        self.activation = activation
        self.blocks_args = blocks_args
        self.model_name = model_name


class EfficientNetB6_Network(EfficientNetBaseNetwork):
    def __init__(self, width_coefficient=1.8, depth_coefficient=2.6, default_size=528, dropout_rate=0.5,
                 drop_connect_rate=0.2, depth_divisor=8, activation='swish', blocks_args='default',
                 model_name='efficientnet_B6', include_top=True, input_tensor=None, input_shape=None, pooling='avg',
                 classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)
        self.width_coefficient = width_coefficient
        self.depth_coefficient = depth_coefficient
        self.default_size = default_size
        self.dropout_rate = dropout_rate
        self.drop_connect_rate = drop_connect_rate
        self.depth_divisor = depth_divisor
        self.activation = activation
        self.blocks_args = blocks_args
        self.model_name = model_name


class EfficientNetB7_Network(EfficientNetBaseNetwork):
    def __init__(self, width_coefficient=2.0, depth_coefficient=3.1, default_size=600, dropout_rate=0.5,
                 drop_connect_rate=0.2, depth_divisor=8, activation='swish', blocks_args='default',
                 model_name='efficientnet_B7', include_top=True, input_tensor=None, input_shape=None, pooling='avg',
                 classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)
        self.width_coefficient = width_coefficient
        self.depth_coefficient = depth_coefficient
        self.default_size = default_size
        self.dropout_rate = dropout_rate
        self.drop_connect_rate = drop_connect_rate
        self.depth_divisor = depth_divisor
        self.activation = activation
        self.blocks_args = blocks_args
        self.model_name = model_name
