from tensorflow.keras.layers import *
from tensorflow.keras.models import Model

from . import network_base


def block_layer(x, n_stage, channel, n_loop):
    """
    x : input_tensor, n_stage = n-th stage(n>1), channel : (a, a, 4a) channels, n_loop = # loops
    """
    # 1 loop : conv_block, n-1 loop: identity_block
    for n in range(1, n_loop + 1):
        x = Conv2D(channel, (3, 3), padding='same', name='block'+str(n_stage)+'_conv'+str(n))(x)
    if n_stage != 5:
        x = MaxPool2D((2, 2), strides=2, name='block'+str(n_stage) + '_pool')(x)
    return x


class VGG16Network(network_base.BaseNetwork):
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling=None, classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)

    def setup(self):
        img_input = self.get_input_tensor()

        x = block_layer(img_input, 1, 64, 2)
        x = block_layer(x, 2, 128, 2)
        x = block_layer(x, 3, 256, 3)
        x = block_layer(x, 4, 512, 3)
        x = block_layer(x, 5, 512, 3)
        x = self.get_pool(x)  # contained flatten

        if self.include_top:
            # x = self.get_top_include(x) # Too many
            x = super().get_top_include(x)
            model = Model(img_input, x, name='VGG16')
            return model
        else:
            return img_input, x

    def get_top_include(self, x):
        x = Dense(4096, activation='relu', name='fc1')(x)
        x = Dense(4096, activation='relu', name='fc2')(x)
        x = Dense(self.classes, activation='softmax', name='FC_' + str(self.classes) + "_classes_0")(x)
        return x


class VGG19Network(network_base.BaseNetwork):
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling=None, classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)

    def setup(self):
        img_input = self.get_input_tensor()

        x = block_layer(img_input, 1, 64, 2)
        x = block_layer(x, 2, 128, 2)
        x = block_layer(x, 3, 256, 4)
        x = block_layer(x, 4, 512, 4)
        x = block_layer(x, 5, 512, 4)
        x = self.get_pool(x)  # contained flatten

        if self.include_top:
            # x = self.get_top_include(x) # Too many
            x = super().get_top_include(x)
            model = Model(img_input, x, name='VGG19')
            return model
        else:
            return x

    def get_top_include(self, x):
        x = Dense(4096, activation='relu', name='fc1')(x)
        x = Dense(4096, activation='relu', name='fc2')(x)
        x = Dense(self.classes, activation='softmax', name='FC_' + str(self.classes) + "_classes_0")(x)
        return x
