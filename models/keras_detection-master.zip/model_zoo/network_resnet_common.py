from tensorflow.keras.layers import *
from tensorflow.keras.models import Model
import numpy as np
from . import network_base


def block1(x, filters, kernel_size=3, stride=1, conv_shortcut=True, name=None):
    bn_axis = 3
    if conv_shortcut is True:
        shortcut = Conv2D(4 * filters, 1, strides=stride,
                          name=name + '_0_conv')(x)
        shortcut = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name=name + '_0_bn')(shortcut)
    else:
        shortcut = x

    x = Conv2D(filters, 1, strides=stride, name=name + '_1_conv')(x)
    x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name=name + '_1_bn')(x)
    x = Activation('relu', name=name + '_1_relu')(x)

    x = Conv2D(filters, kernel_size, padding='SAME', name=name + '_2_conv')(x)
    x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name=name + '_2_bn')(x)
    x = Activation('relu', name=name + '_2_relu')(x)

    x = Conv2D(4 * filters, 1, name=name + '_3_conv')(x)
    x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name=name + '_3_bn')(x)

    x = Add(name=name + '_add')([shortcut, x])
    x = Activation('relu', name=name + '_out')(x)
    return x


def block2(x, filters, kernel_size=3, stride=1, conv_shortcut=False, name=None):
    bn_axis = 3
    preact = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name=name + '_preact_bn')(x)
    preact = Activation('relu', name=name + '_preact_relu')(preact)

    if conv_shortcut is True:
        shortcut = Conv2D(4 * filters, 1, strides=stride, name=name + '_0_conv')(preact)
    else:
        shortcut = MaxPooling2D(1, strides=stride)(x) if stride > 1 else x

    x = Conv2D(filters, 1, strides=1, use_bias=False, name=name + '_1_conv')(preact)
    x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name=name + '_1_bn')(x)
    x = Activation('relu', name=name + '_1_relu')(x)

    x = ZeroPadding2D(padding=((1, 1), (1, 1)), name=name + '_2_pad')(x)
    x = Conv2D(filters, kernel_size, strides=stride, use_bias=False, name=name + '_2_conv')(x)
    x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name=name + '_2_bn')(x)
    x = Activation('relu', name=name + '_2_relu')(x)

    x = Conv2D(4 * filters, 1, name=name + '_3_conv')(x)
    x = Add(name=name + '_out')([shortcut, x])
    return x


def stack1(x, filters, blocks, stride1=2, name=None):
    x = block1(x, filters, stride=stride1, name=name + '_block1')
    for i in range(2, blocks + 1):
        x = block1(x, filters, conv_shortcut=False, name=name + '_block' + str(i))
    return x


def stack2(x, filters, blocks, stride1=2, name=None):
    x = block2(x, filters, conv_shortcut=True, name=name + '_block1')
    for i in range(2, blocks):
        x = block2(x, filters, name=name + '_block' + str(i))
    x = block2(x, filters, stride=stride1, name=name + '_block' + str(blocks))
    return x


def block3(x, filters, kernel_size=3, stride=1, groups=32, conv_shortcut=True, name=None):
    bn_axis = 3
    if conv_shortcut is True:
        shortcut = Conv2D((64 // groups) * filters, 1, strides=stride, use_bias=False, name=name + '_0_conv')(x)
        shortcut = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name=name + '_0_bn')(shortcut)
    else:
        shortcut = x

    x = Conv2D(filters, 1, use_bias=False, name=name + '_1_conv')(x)
    x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name=name + '_1_bn')(x)
    x = Activation('relu', name=name + '_1_relu')(x)

    c = filters // groups
    x = ZeroPadding2D(padding=((1, 1), (1, 1)), name=name + '_2_pad')(x)
    x = DepthwiseConv2D(kernel_size, strides=stride, depth_multiplier=c, use_bias=False, name=name + '_2_conv')(x)
    kernel = np.zeros((1, 1, filters * c, filters), dtype=np.float32)
    for i in range(filters):
        start = (i // c) * c * c + i % c
        end = start + c * c
        kernel[:, :, start:end:c, i] = 1.
    x = Conv2D(filters, 1, use_bias=False, trainable=False,
               kernel_initializer={'class_name': 'Constant', 'config': {'value': kernel}},
               name=name + '_2_gconv')(x)
    x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name=name + '_2_bn')(x)
    x = Activation('relu', name=name + '_2_relu')(x)

    x = Conv2D((64 // groups) * filters, 1, use_bias=False, name=name + '_3_conv')(x)
    x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name=name + '_3_bn')(x)

    x = Add(name=name + '_add')([shortcut, x])
    x = Activation('relu', name=name + '_out')(x)
    return x


def stack3(x, filters, blocks, stride1=2, groups=32, name=None):
    x = block3(x, filters, stride=stride1, groups=groups, name=name + '_block1')
    for i in range(2, blocks + 1):
        x = block3(x, filters, groups=groups, conv_shortcut=False, name=name + '_block' + str(i))
    return x


def ResNet_frame(stack_fn, preact, use_bias, img_input=None):
    bn_axis = 3
    x = ZeroPadding2D(padding=((3, 3), (3, 3)), name='conv1_pad')(img_input)
    x = Conv2D(64, 7, strides=2, use_bias=use_bias, name='conv1_conv')(x)
    if preact is False:
        x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name='conv1_bn')(x)
        x = Activation('relu', name='conv1_relu')(x)
    x = ZeroPadding2D(padding=((1, 1), (1, 1)), name='pool1_pad')(x)
    x = MaxPooling2D(3, strides=2, name='pool1_pool')(x)
    x = stack_fn(x)

    if preact is True:
        x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name='post_bn')(x)
        x = Activation('relu', name='post_relu')(x)
    return x


class ResnetBaseNetwork(network_base.BaseNetwork):
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling=None, classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)


class ResNet50Network(ResnetBaseNetwork):
    def setup(self):
        img_input = self.get_input_tensor()
        x = ResNet_frame(stack_fn=self.stack_fn, preact=False, use_bias=True, img_input=img_input)
        x = self.get_pool(x)
        if self.include_top:
            x = self.get_top_include(x)
            model = Model(img_input, x, name='Resnet50-v1')
            return model
        else:
            return x

    def stack_fn(self, x):
        x = stack1(x, 64, 3, stride1=1, name='conv2')
        x = stack1(x, 128, 4, name='conv3')
        x = stack1(x, 256, 6, name='conv4')
        x = stack1(x, 512, 3, name='conv5')
        return x


class ResNet101Network(ResnetBaseNetwork):
    def setup(self):
        img_input = self.get_input_tensor()
        x = ResNet_frame(stack_fn=self.stack_fn, preact=False, use_bias=True, img_input=img_input)
        x = self.get_pool(x)
        if self.include_top:
            x = self.get_top_include(x)
            model = Model(img_input, x, name='Resnet101-v1')
            return model
        else:
            return x

    def stack_fn(self, x):
        x = stack1(x, 64, 3, stride1=1, name='conv2')
        x = stack1(x, 128, 4, name='conv3')
        x = stack1(x, 256, 23, name='conv4')
        x = stack1(x, 512, 3, name='conv5')
        return x


class ResNet152Network(ResnetBaseNetwork):
    def setup(self):
        img_input = self.get_input_tensor()
        x = ResNet_frame(stack_fn=self.stack_fn, preact=False, use_bias=True, img_input=img_input)
        x = self.get_pool(x)
        if self.include_top:
            x = self.get_top_include(x)
            model = Model(img_input, x, name='Resnet50-v1')
            return model
        else:
            return x

    def stack_fn(self, x):
        x = stack1(x, 64, 3, stride1=1, name='conv2')
        x = stack1(x, 128, 8, name='conv3')
        x = stack1(x, 256, 36, name='conv4')
        x = stack1(x, 512, 3, name='conv5')
        return x


class ResNet50NetworkV2(ResnetBaseNetwork):
    def setup(self):
        img_input = self.get_input_tensor()
        x = ResNet_frame(stack_fn=self.stack_fn, preact=True, use_bias=True, img_input=img_input)
        x = self.get_pool(x)
        if self.include_top:
            x = self.get_top_include(x)
            model = Model(img_input, x, name='Resnet50-v2')
            return model
        else:
            return x

    def stack_fn(self, x):
        x = stack2(x, 64, 3, name='conv2')
        x = stack2(x, 128, 4, name='conv3')
        x = stack2(x, 256, 6, name='conv4')
        x = stack2(x, 512, 3, stride1=1, name='conv5')
        return x


class ResNet101NetworkV2(ResnetBaseNetwork):
    def setup(self):
        img_input = self.get_input_tensor()
        x = ResNet_frame(stack_fn=self.stack_fn, preact=True, use_bias=True, img_input=img_input)
        x = self.get_pool(x)
        if self.include_top:
            x = self.get_top_include(x)
            model = Model(img_input, x, name='Resnet101-v2')
            return model
        else:
            return x

    def stack_fn(self, x):
        x = stack2(x, 64, 3,  name='conv2')
        x = stack2(x, 128, 4, name='conv3')
        x = stack2(x, 256, 23, name='conv4')
        x = stack2(x, 512, 3, stride1=1, name='conv5')
        return x


class ResNet152NetworkV2(ResnetBaseNetwork):
    def setup(self):
        img_input = self.get_input_tensor()
        x = ResNet_frame(stack_fn=self.stack_fn, preact=True, use_bias=True, img_input=img_input)
        x = self.get_pool(x)
        if self.include_top:
            x = self.get_top_include(x)
            model = Model(img_input, x, name='Resnet152-v2')
            return model
        else:
            return x

    def stack_fn(self, x):
        x = stack2(x, 64, 3, name='conv2')
        x = stack2(x, 128, 8, name='conv3')
        x = stack2(x, 256, 36, name='conv4')
        x = stack2(x, 512, 3, stride1=1, name='conv5')
        return x


class ResNext50Network(ResnetBaseNetwork):
    def setup(self):
        img_input = self.get_input_tensor()
        x = ResNet_frame(stack_fn=self.stack_fn, preact=False, use_bias=False, img_input=img_input)
        x = self.get_pool(x)
        if self.include_top:
            x = self.get_top_include(x)
            model = Model(img_input, x, name='ResNext50')
            return model
        else:
            return x

    def stack_fn(self, x):
        x = stack3(x, 128, 3, stride1=1, name='conv2')
        x = stack3(x, 256, 4, name='conv3')
        x = stack3(x, 512, 6, name='conv4')
        x = stack3(x, 1024, 3, name='conv5')
        return x


class ResNext101Network(ResnetBaseNetwork):
    def setup(self):
        img_input = self.get_input_tensor()
        x = ResNet_frame(stack_fn=self.stack_fn, preact=False, use_bias=False, img_input=img_input)
        x = self.get_pool(x)
        if self.include_top:
            x = self.get_top_include(x)
            model = Model(img_input, x, name='ResNext101')
            return model
        else:
            return x

    def stack_fn(self, x):
        x = stack3(x, 128, 3, stride1=1, name='conv2')
        x = stack3(x, 256, 4, name='conv3')
        x = stack3(x, 512, 6, name='conv4')
        x = stack3(x, 1024, 3, name='conv5')
        return x