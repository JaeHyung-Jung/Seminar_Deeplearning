from tensorflow.keras.layers import *
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam

from . import network_base


def inception_resnet_v1_stem(x):
    c = Conv2D(32, (3, 3), activation='relu', strides=(2, 2))(x)
    c = Conv2D(32, (3, 3), activation='relu', )(c)
    c = Conv2D(64, (3, 3), activation='relu', padding='same')(c)

    c = MaxPool2D((3, 3), strides=(2, 2))(c)

    c = Conv2D(80, (1, 1), activation='relu', padding='same')(c)
    c = Conv2D(192, (3, 3), activation='relu')(c)
    c = Conv2D(256, (3, 3), activation='relu', strides=(2, 2), padding='same')(c)
    b = BatchNormalization()(c)
    b = Activation('relu')(b)
    return b


def inception_resnet_v2_stem(x):
    c = Conv2D(32, (3, 3), activation='relu', strides=(2, 2))(x)
    c = Conv2D(32, (3, 3), activation='relu', )(c)
    c = Conv2D(64, (3, 3), activation='relu',  padding='same')(c)

    c1 = MaxPool2D((3, 3), strides=(2, 2))(c)
    c2 = Conv2D(96, (3, 3), activation='relu', strides=2)(c)

    m = concatenate([c1, c2], axis=3)

    c1 = Conv2D(64, (1, 1), activation='relu')(m)
    c1 = Conv2D(96, (3, 3), activation='relu')(c1)

    c2 = Conv2D(64, (1, 1), activation='relu')(m)
    c2 = Conv2D(64, (7, 1), activation='relu', padding='same')(c2)
    c2 = Conv2D(64, (1, 7), activation='relu', padding='same')(c2)
    c2 = Conv2D(96, (3, 3), activation='relu')(c2)

    m2 = concatenate([c1, c2], axis=3)

    p1 = MaxPool2D((3, 3), strides=(2, 2))(m2)
    p2 = Conv2D(192, (3, 3), strides=(2, 2))(m2)

    m3 = concatenate([p1, p2], axis=3)
    m3 = BatchNormalization()(m3)
    m3 = Activation('relu')(m3)
    return m3


def inception_resnet_A(x, channels_mode='v1', scale_residual=True):
    if channels_mode == 'v1':
        channels = [32, 32, 32, 32, 32, 32, 256]
    elif channels_mode == 'v2':
        channels = [32, 32, 32, 32, 48, 64, 384]
    else:
        raise ValueError("Please Input 'v1' or 'v2' values !! ")

    # Input is relu activation
    init = x
    ir1 = Conv2D(channels[0], (1, 1), activation='relu', padding='same')(init)

    ir2 = Conv2D(channels[1], (1, 1), activation='relu', padding='same')(init)
    ir2 = Conv2D(channels[2], (3, 3), activation='relu', padding='same')(ir2)

    ir3 = Conv2D(channels[3], (1, 1), activation='relu', padding='same')(init)
    ir3 = Conv2D(channels[4], (3, 3), activation='relu', padding='same')(ir3)
    ir3 = Conv2D(channels[5], (3, 3), activation='relu', padding='same')(ir3)

    ir_merge = concatenate([ir1, ir2, ir3], axis=3)
    ir_conv = Conv2D(channels[6], (1, 1), activation='linear', padding='same')(ir_merge)
    if scale_residual:
        ir_conv = Lambda(lambda w: w * 0.1)(ir_conv)

    out = add([init, ir_conv])
    out = BatchNormalization()(out)
    out = Activation("relu")(out)
    return out


def inception_resnet_B(x, channels_mode='v1', scale_residual=True):
    if channels_mode == 'v1':
        channels = [128, 128, 128, 128, 896]
    elif channels_mode == 'v2':
        channels = [192, 128, 160, 192, 1152]
    else:
        raise ValueError("Please Input 'v1' or 'v2' values !! ")

    # Input is relu activation
    init = x

    ir1 = Conv2D(channels[0], (1, 1), activation='relu', padding='same')(init)

    ir2 = Conv2D(channels[1], (1, 1), activation='relu', padding='same')(init)
    ir2 = Conv2D(channels[2], (1, 7), activation='relu', padding='same')(ir2)
    ir2 = Conv2D(channels[3], (7, 1), activation='relu', padding='same')(ir2)

    ir_merge = concatenate([ir1, ir2], axis=3)
    ir_conv = Conv2D(channels[4], (1, 1), activation='linear', padding='same')(ir_merge)
    if scale_residual:
        ir_conv = Lambda(lambda p: p * 0.1)(ir_conv)

    out = add([init, ir_conv])
    out = BatchNormalization()(out)
    out = Activation("relu")(out)
    return out


def inception_resnet_C(x, channels_mode='v1', scale_residual=True):
    if channels_mode == 'v1':
        channels = [192, 192, 192, 192, 1792]
    elif channels_mode == 'v2':
        channels = [192, 192, 224, 256, 2144]
    else:
        raise ValueError("Please Input 'v1' or 'v2' values !! ")
    # Input is relu activation
    init = x

    ir1 = Conv2D(channels[0], (1, 1), activation='relu', padding='same')(init)

    ir2 = Conv2D(channels[1], (1, 1), activation='relu', padding='same')(init)
    ir2 = Conv2D(channels[2], (1, 3), activation='relu', padding='same')(ir2)
    ir2 = Conv2D(channels[3], (3, 1), activation='relu', padding='same')(ir2)

    ir_merge = concatenate([ir1, ir2], axis=3)
    ir_conv = Conv2D(channels[4], (1, 1), activation='linear', padding='same')(ir_merge)
    if scale_residual:
        ir_conv = Lambda(lambda w: w * 0.1)(ir_conv)

    out = Add()([init, ir_conv])
    out = BatchNormalization()(out)
    out = Activation("relu")(out)
    return out


def reduction_A(x, channels_mode='v1'):
    if channels_mode == 'v1':
        k, l, m, n = [192, 192, 256, 384]
    elif channels_mode == 'v2':
        k, l, m, n = [256, 256, 384, 384]

    r1 = MaxPool2D((3, 3), strides=(2, 2), padding='valid')(x)

    r2 = Conv2D(n, (3, 3), activation='relu', strides=(2, 2), padding='valid')(x)

    r3 = Conv2D(k, (1, 1), activation='relu', padding='same')(x)
    r3 = Conv2D(l, (3, 3), activation='relu', padding='same')(r3)
    r3 = Conv2D(m, (3, 3), activation='relu', strides=(2, 2), padding='valid')(r3)

    m = concatenate([r1, r2, r3], axis=3)
    m = BatchNormalization()(m)
    m = Activation('relu')(m)
    return m


def reduction_B(x, channels_mode='v1'):
    if channels_mode == 'v1':
        channels = [256, 384, 256, 256, 256, 256, 256]
    elif channels_mode == 'v2':
        channels = [256, 384, 256, 288, 256, 288, 320]
    else:
        raise ValueError("Please Input 'v1' or 'v2' values !! ")
    r1 = MaxPool2D((3, 3), strides=(2, 2), padding='valid')(x)

    r2 = Conv2D(channels[0], (1, 1), activation='relu', padding='same')(x)
    r2 = Conv2D(channels[1], (3, 3), activation='relu', strides=(2, 2), padding='valid')(r2)

    r3 = Conv2D(channels[2], (1, 1), activation='relu', padding='same')(x)
    r3 = Conv2D(channels[3], (3, 3), activation='relu', strides=(2, 2), padding='valid')(r3)

    r4 = Conv2D(channels[4], (1, 1), activation='relu', padding='same')(x)
    r4 = Conv2D(channels[5], (3, 3), activation='relu', padding='same')(r4)
    r4 = Conv2D(channels[6], (3, 3), activation='relu', strides=(2, 2), padding='valid')(r4)

    m = concatenate([r1, r2, r3, r4], axis=3)
    m = BatchNormalization()(m)
    m = Activation('relu')(m)
    return m


class Inception_ResNet_network_v1(network_base.BaseNetwork):
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling=None, classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)

    def setup(self, scale=True):
        img_input = self.get_input_tensor()
        x = inception_resnet_v1_stem(img_input)

        for i in range(5):
            x = inception_resnet_A(x, channels_mode='v1', scale_residual=scale)  # 5 x Inception Resnet A

        x = reduction_A(x, channels_mode='v1')  # Reduction A - From Inception v4

        for i in range(10):
            x = inception_resnet_B(x, channels_mode='v1',  scale_residual=scale)  # 10 x Inception Resnet B

        aux_out = AveragePooling2D((5, 5), strides=(3, 3))(x)  # Auxiliary tower
        aux_out = Conv2D(128, (1, 1), padding='same', activation='relu')(aux_out)
        aux_out = Conv2D(768, (5, 5), activation='relu')(aux_out)
        aux_out = self.get_pool(aux_out)
        if self.include_top:
            aux_out = self.get_top_include(aux_out)

        x = reduction_B(x, channels_mode='v1')  # Reduction Resnet B

        for i in range(5):
            x = inception_resnet_C(x, channels_mode='v1', scale_residual=scale)  # 5 x Inception Resnet C

        x = AveragePooling2D((8, 8))(x)  # Average Pooling

        x = Dropout(0.8)(x)  # Dropout
        out = self.get_pool(x)  # Output

        if self.include_top:
            out = self.get_top_include(out)
            model = Model(img_input, [aux_out, out], name='Inception_ResNet_v1')
            return model
        else:
            return [aux_out, out]

    def get_loss(self, lr=.001):
        opt = Adam(lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.01, amsgrad=False)
        if self.include_top:  # else 는 다음 object detection 을 위해 남겨두자.
            loss = ['categorical_crossentropy', 'categorical_crossentropy']
            metrics = ['accuracy']
            return loss, metrics, opt


class Inception_ResNet_network_v2(network_base.BaseNetwork):
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling=None, classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)

    def setup(self, scale=True):
        img_input = self.get_input_tensor()
        x = inception_resnet_v2_stem(img_input)

        for i in range(5):
            x = inception_resnet_A(x, channels_mode='v2', scale_residual=scale)  # 5 x Inception Resnet A

        x = reduction_A(x, channels_mode='v2')  # Reduction A - From Inception v4

        for i in range(10):
            x = inception_resnet_B(x, channels_mode='v2',  scale_residual=scale)  # 10 x Inception Resnet B

        aux_out = AveragePooling2D((5, 5), strides=(3, 3))(x)  # Auxiliary tower
        aux_out = Conv2D(128, (1, 1), padding='same', activation='relu')(aux_out)
        aux_out = Conv2D(768, (5, 5), activation='relu')(aux_out)
        aux_out = self.get_pool(aux_out)
        if self.include_top:
            aux_out = self.get_top_include(aux_out)

        x = reduction_B(x, channels_mode='v2')  # Reduction Resnet B

        for i in range(5):
            x = inception_resnet_C(x, channels_mode='v2', scale_residual=scale)  # 5 x Inception Resnet C

        x = AveragePooling2D((8, 8))(x)  # Average Pooling

        x = Dropout(0.8)(x)  # Dropout
        out = self.get_pool(x)  # Output

        if self.include_top:
            out = self.get_top_include(out)
            model = Model(img_input, [aux_out, out], name='Inception_ResNet_v2')
            return model
        else:
            return [aux_out, out]

    def get_loss(self, lr=.001):
        opt = Adam(lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.01, amsgrad=False)
        if self.include_top:  # else 는 다음 object detection 을 위해 남겨두자.
            loss = ['categorical_crossentropy', 'categorical_crossentropy']
            metrics = ['accuracy']
            return loss, metrics, opt
