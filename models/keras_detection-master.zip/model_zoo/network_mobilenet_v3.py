from tensorflow.keras.layers import *
from tensorflow.keras.models import Model
from tensorflow.keras import backend as K
from . import network_base


def correct_pad(inputs, kernel_size):
    """Returns a tuple for zero-padding for 2D convolution with downsampling.

    Arguments:
    inputs: Input tensor.
    kernel_size: An integer or tuple/list of 2 integers.

    Returns:
    A tuple.
    """
    img_dim = 2 if K.image_data_format() == 'channels_first' else 1
    input_size = K.int_shape(inputs)[img_dim:(img_dim + 2)]
    if isinstance(kernel_size, int):
        kernel_size = (kernel_size, kernel_size)
    if input_size[0] is None:
        adjust = (1, 1)
    else:
        adjust = (1 - input_size[0] % 2, 1 - input_size[1] % 2)
    correct = (kernel_size[0] // 2, kernel_size[1] // 2)
    return ((correct[0] - adjust[0], correct[0]),
            (correct[1] - adjust[1], correct[1]))


def relu(x):
    return ReLU()(x)


def hard_sigmoid(x):
    return ReLU(6.)(x + 3.) * (1. / 6.)


def hard_swish(x):
    return Multiply()([Activation(hard_sigmoid)(x), x])


def _depth(v, divisor=8, min_value=None):
    if min_value is None:
        min_value = divisor
    new_v = max(min_value, int(v + divisor / 2) // divisor * divisor)
    # Make sure that round down does not go down by more than 10%.
    if new_v < 0.9 * v:
        new_v += divisor
    return new_v


def _se_block(inputs, filters, se_ratio, prefix):
    x = GlobalAveragePooling2D(name=prefix + 'squeeze_excite/AvgPool')(inputs)
    if K.image_data_format() == 'channels_first':
        x = Reshape((filters, 1, 1))(x)
    else:
        x = Reshape((1, 1, filters))(x)
    x = Conv2D(_depth(filters * se_ratio), kernel_size=1, padding='same', name=prefix + 'squeeze_excite/Conv')(x)
    x = ReLU(name=prefix + 'squeeze_excite/Relu')(x)
    x = Conv2D(filters, kernel_size=1, padding='same', name=prefix + 'squeeze_excite/Conv_1')(x)
    x = Activation(hard_sigmoid)(x)
    x = Multiply(name=prefix + 'squeeze_excite/Mul')([inputs, x])
    return x


def _inverted_res_block(x, expansion, filters, kernel_size, stride, se_ratio, activation, block_id):
    channel_axis = 1 if K.image_data_format() == 'channels_first' else -1
    shortcut = x
    prefix = 'expanded_conv/'
    infilters = K.int_shape(x)[channel_axis]
    if block_id:
        # Expand
        prefix = 'expanded_conv_{}/'.format(block_id)
        x = Conv2D(_depth(infilters * expansion), kernel_size=1, padding='same',
                   use_bias=False, name=prefix + 'expand')(x)
        x = BatchNormalization(axis=channel_axis, epsilon=1e-3, momentum=0.999, name=prefix + 'expand/BatchNorm')(x)
        x = Activation(activation)(x)

    if stride == 2:
        x = ZeroPadding2D(padding=correct_pad(x, kernel_size), name=prefix + 'depthwise/pad')(x)
    x = DepthwiseConv2D(kernel_size, strides=stride, padding='same' if stride == 1 else 'valid',
                        use_bias=False, name=prefix + 'depthwise')(x)
    x = BatchNormalization(axis=channel_axis, epsilon=1e-3, momentum=0.999, name=prefix + 'depthwise/BatchNorm')(x)
    x = Activation(activation)(x)

    if se_ratio:
        x = _se_block(x, _depth(infilters * expansion), se_ratio, prefix)

    x = Conv2D(filters, kernel_size=1, padding='same', use_bias=False, name=prefix + 'project')(x)
    x = BatchNormalization(axis=channel_axis, epsilon=1e-3, momentum=0.999, name=prefix + 'project/BatchNorm')(x)

    if stride == 1 and infilters == filters:
        x = Add(name=prefix + 'Add')([shortcut, x])
    return x


class Mobilenet_v3_small_Network(network_base.BaseNetwork):
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling='avg', classes=2,
                 alpha=1, minimalistic=False, last_point_ch=1024, dropout_rate=0.2):
        self.alpha = alpha
        self.minimalistic = minimalistic
        self.last_point_ch = last_point_ch
        self.dropout_rate = dropout_rate
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)

    def setup(self):
        # structures
        img_input = self.get_input_tensor()
        channel_axis = 1 if K.image_data_format() == 'channels_first' else -1
        if self.minimalistic:
            kernel = 3
            activation = relu
            se_ratio = None
        else:
            kernel = 5
            activation = hard_swish
            se_ratio = 0.25

        x = ZeroPadding2D(padding=correct_pad(img_input, (3, 3)), name='Conv_pad')(img_input)
        x = Conv2D(16, kernel_size=3, strides=(2, 2), padding='valid', use_bias=False, name='Conv')(x)
        x = BatchNormalization(axis=channel_axis, epsilon=1e-3, momentum=0.999, name='Conv/BatchNorm')(x)
        x = Activation(activation)(x)

        x = self.stack_fn(x, kernel, activation, se_ratio)

        last_conv_ch = _depth(K.int_shape(x)[channel_axis] * 6)

        # if the width multiplier is greater than 1 we
        # increase the number of output channels
        if self.alpha > 1.0:
            last_point_ch = _depth(self.last_point_ch * self.alpha)
        else:
            last_point_ch = self.last_point_ch

        x = Conv2D(last_conv_ch, kernel_size=1, padding='same', use_bias=False, name='Conv_1')(x)
        x = BatchNormalization(axis=channel_axis, epsilon=1e-3, momentum=0.999, name='Conv_1/BatchNorm')(x)
        x = Activation(activation)(x)
        x = self.get_pool(x)
        if self.include_top:
            if channel_axis == 1:
                x = Reshape((last_conv_ch, 1, 1))(x)
            else:
                x = Reshape((1, 1, last_conv_ch))(x)
            x = Conv2D(last_point_ch, kernel_size=1, padding='same', name='Conv_2')(x)
            x = Activation(activation)(x)
            if self.dropout_rate > 0:
                x = Dropout(self.dropout_rate)(x)
            x = Conv2D(self.classes, kernel_size=1, padding='same', name='Logits')(x)
            x = Flatten()(x)
            x = Softmax(name='Predictions/Softmax')(x)
            model = Model(img_input, x, name='mobilenet_v3_small')
            return model
        else:
            if self.pooling == 'avg':
                x = GlobalAveragePooling2D(name='avg_pool')(x)
            elif self.pooling == 'max':
                x = GlobalMaxPooling2D(name='max_pool')(x)
            elif self.pooling == 'flatten':
                x = Flatten()(x)
            return x

    def stack_fn(self, x, kernel, activation, se_ratio):
        def depth(d):
            return _depth(d * self.alpha)
        x = _inverted_res_block(x, 1, depth(16), 3, 2, se_ratio, relu, 0)
        x = _inverted_res_block(x, 72. / 16, depth(24), 3, 2, None, relu, 1)
        x = _inverted_res_block(x, 88. / 24, depth(24), 3, 1, None, relu, 2)
        x = _inverted_res_block(x, 4, depth(40), kernel, 2, se_ratio, activation, 3)
        x = _inverted_res_block(x, 6, depth(40), kernel, 1, se_ratio, activation, 4)
        x = _inverted_res_block(x, 6, depth(40), kernel, 1, se_ratio, activation, 5)
        x = _inverted_res_block(x, 3, depth(48), kernel, 1, se_ratio, activation, 6)
        x = _inverted_res_block(x, 3, depth(48), kernel, 1, se_ratio, activation, 7)
        x = _inverted_res_block(x, 6, depth(96), kernel, 2, se_ratio, activation, 8)
        x = _inverted_res_block(x, 6, depth(96), kernel, 1, se_ratio, activation, 9)
        x = _inverted_res_block(x, 6, depth(96), kernel, 1, se_ratio, activation, 10)
        return x


class Mobilenet_v3_large_Network(network_base.BaseNetwork):
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling='avg', classes=2,
                 alpha=1, minimalistic=False, last_point_ch=1280, dropout_rate=0.2):
        self.alpha = alpha
        self.minimalistic = minimalistic
        self.last_point_ch = last_point_ch
        self.dropout_rate = dropout_rate
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)

    def setup(self):
        # structures
        img_input = self.get_input_tensor()
        channel_axis = 1 if K.image_data_format() == 'channels_first' else -1

        if self.minimalistic:
            kernel = 3
            activation = relu
            se_ratio = None
        else:
            kernel = 5
            activation = hard_swish
            se_ratio = 0.25

        x = ZeroPadding2D(padding=correct_pad(img_input, (3, 3)), name='Conv_pad')(img_input)
        x = Conv2D(16, kernel_size=3, strides=(2, 2), padding='valid', use_bias=False, name='Conv')(x)
        x = BatchNormalization(axis=channel_axis, epsilon=1e-3, momentum=0.999, name='Conv/BatchNorm')(x)
        x = Activation(activation)(x)

        x = self.stack_fn(x, kernel, activation, se_ratio)

        last_conv_ch = _depth(K.int_shape(x)[channel_axis] * 6)

        # if the width multiplier is greater than 1 we
        # increase the number of output channels
        if self.alpha > 1.0:
            last_point_ch = _depth(self.last_point_ch * self.alpha)
        else:
            last_point_ch = self.last_point_ch
        x = Conv2D(last_conv_ch, kernel_size=1, padding='same', use_bias=False, name='Conv_1')(x)
        x = BatchNormalization(axis=channel_axis, epsilon=1e-3, momentum=0.999, name='Conv_1/BatchNorm')(x)
        x = Activation(activation)(x)
        x = self.get_pool(x)
        if self.include_top:
            if channel_axis == 1:
                x = Reshape((last_conv_ch, 1, 1))(x)
            else:
                x = Reshape((1, 1, last_conv_ch))(x)
            x = Conv2D(last_point_ch, kernel_size=1, padding='same', name='Conv_2')(x)
            x = Activation(activation)(x)
            if self.dropout_rate > 0:
                x = Dropout(self.dropout_rate)(x)
            x = Conv2D(self.classes, kernel_size=1, padding='same', name='Logits')(x)
            x = Flatten()(x)
            x = Softmax(name='Predictions/Softmax')(x)
            model = Model(img_input, x, name='mobilenet_v3_small')
            return model
        else:
            if self.pooling == 'avg':
                x = GlobalAveragePooling2D(name='avg_pool')(x)
            elif self.pooling == 'max':
                x = GlobalMaxPooling2D(name='max_pool')(x)
            elif self.pooling == 'flatten':
                x = Flatten()(x)
            return x

    def stack_fn(self, x, kernel, activation, se_ratio):
        def depth(d):
            return _depth(d * self.alpha)

        x = _inverted_res_block(x, 1, depth(16), 3, 1, None, relu, 0)
        x = _inverted_res_block(x, 4, depth(24), 3, 2, None, relu, 1)
        x = _inverted_res_block(x, 3, depth(24), 3, 1, None, relu, 2)
        x = _inverted_res_block(x, 3, depth(40), kernel, 2, se_ratio, relu, 3)
        x = _inverted_res_block(x, 3, depth(40), kernel, 1, se_ratio, relu, 4)
        x = _inverted_res_block(x, 3, depth(40), kernel, 1, se_ratio, relu, 5)
        x = _inverted_res_block(x, 6, depth(80), 3, 2, None, activation, 6)
        x = _inverted_res_block(x, 2.5, depth(80), 3, 1, None, activation, 7)
        x = _inverted_res_block(x, 2.3, depth(80), 3, 1, None, activation, 8)
        x = _inverted_res_block(x, 2.3, depth(80), 3, 1, None, activation, 9)
        x = _inverted_res_block(x, 6, depth(112), 3, 1, se_ratio, activation, 10)
        x = _inverted_res_block(x, 6, depth(112), 3, 1, se_ratio, activation, 11)
        x = _inverted_res_block(x, 6, depth(160), kernel, 2, se_ratio, activation, 12)
        x = _inverted_res_block(x, 6, depth(160), kernel, 1, se_ratio, activation, 13)
        x = _inverted_res_block(x, 6, depth(160), kernel, 1, se_ratio, activation, 14)
        return x
