from __future__ import absolute_import
from tensorflow.keras.layers import *
from tensorflow.keras.optimizers import Adam
from tensorflow.keras import backend as K

class BaseNetwork(object):
    def __init__(self, include_top, input_tensor, input_shape, pooling, classes):
        """construct the network :
                Param Need )\n
                include_top : True (return classifier model), False(return layers)\n
                pooling : avg, max(Global*PoolingLayer), flatten( a method)\n
                input_shape : e.g. (1280, 1024) (224, 224) etc.\n
                classes : if include_top is true, classify # classes\n"""
        self.include_top = include_top
        self.input_tensor = input_tensor
        self.input_shape = input_shape
        self.pooling = pooling
        self.classes = classes
        self.count = 0

    def setup(self):
        """
        include_top == True
        :return: Model with Dense layer to classify
        """
        pass

    def get_loss(self, lr=.001):
        """
        include_top : True =>  classify! \n
        returns loss(categorical_cross_entropy), metrics(accuracy), optimizer(Set Adam =lr)
        """
        opt = Adam(lr=lr, beta_1=0.9, beta_2=0.999, epsilon=None, decay=0.01, amsgrad=False)
        if self.include_top:  # else 는 다음 object detection 을 위해 남겨두자.
            loss = ['categorical_crossentropy']
            metrics = ['accuracy']
            # model.compile(loss=['categorical_crossentropy'], optimizer=opt, metrics=['accuracy'])
            return loss, metrics, opt

    def get_pool(self, x):
        if self.pooling == 'avg':
            x = GlobalAveragePooling2D()(x)
        elif self.pooling == 'max':
            x = GlobalMaxPooling2D()(x)
        elif self.pooling == 'flatten':
            x = Flatten()(x)
        elif (self.pooling == 'None') or (self.pooling is None):
            pass
        else:
            raise ValueError("Please Input 'avg', 'max', 'flatten', 'None'")
        return x

    def get_top_include(self, x):
        x = Dense(self.classes, activation='softmax', name='FC_' + str(self.classes) + "_classes_" + str(self.count))(x)
        self.count += 1
        return x

    def get_input_tensor(self):
        if self.input_tensor is None:
            img_input = Input(shape=self.input_shape, dtype='float32')
        else:
            img_input = Input(tensor=self.input_tensor, shape=self.input_shape)
        return img_input
