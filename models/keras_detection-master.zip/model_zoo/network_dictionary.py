from model_zoo import network_inception_resnet
from model_zoo import network_vgg
from model_zoo import network_mobilenet_v1
from model_zoo import network_mobilenet_v2
from model_zoo import network_mobilenet_v3
from model_zoo import network_xception
from model_zoo import network_resnet_common
from model_zoo import network_densenet
from model_zoo import network_nasnet
from model_zoo import network_InceptionV3
from model_zoo import network_efficientnet


inceptionresnetv1 = "inceptionresnetv1"; inceptionresnetv2 = "inceptionresnetv2"; vgg16 = "vgg16"; vgg19 = "vgg19"
inceptionv3 = "inceptionv3"; nasnetmobile = "nasnetmobile"; nasnetlarge = "nasnetlarge"
resnet50v1 = "resnet50v1"; resnet50v2 = "resnet50v2"; resnet101v1 = "resnet101v1"; resnet101v2 = "resnet101v1"
resnext50 = "resnext50"; resnext101 = "resnext101" ; xception = "xception"; densenet121 = "densenet121"
densenet169 = "densenet169"; densenet201 = "densenet201"; mobilenetv1 = "mobilenetv1"; mobilenetv2 = "mobilenetv2"
mobilenetsmallv3 = "mobilenetsmallv3"; mobilenetlargev3 = "mobilenetlargev3"; efficientnetb0 = "efficientnetb0"
efficientnetb1 = "efficientnetb1"; efficientnetb2 = "efficientnetb2"; efficientnetb3 = "efficientnetb3"
efficientnetb4 = "efficientnetb4"; efficientnetb5 = "efficientnetb5"; efficientnetb6 = "efficientnetb6"
efficientnetb7 = "efficientnetb7"; resnet152v1 = "resnet152v1"; resnet152v2 = "resnet152v2"


def call(model="", input_shape=None, input_tensor=None, include_top=True, pooling='avg', classes=1000,
         alpha=1.0, depth_multiplier=1, ):
    if model == inceptionresnetv1:
        return network_inception_resnet.Inception_ResNet_network_v1(input_shape=input_shape,
                                                                    input_tensor=input_tensor,
                                                                    include_top=include_top,
                                                                    pooling=pooling,
                                                                    classes=classes)
    elif model == inceptionresnetv2:
        return network_inception_resnet.Inception_ResNet_network_v2(input_shape=input_shape,
                                                                    input_tensor=input_tensor,
                                                                    include_top=include_top,
                                                                    pooling=pooling,
                                                                    classes=classes)
    elif model == vgg16:
        return network_vgg.VGG16Network(input_shape=input_shape,
                                        input_tensor=input_tensor,
                                        include_top=include_top,
                                        pooling=pooling,
                                        classes=classes)
    elif model == vgg19:
        return network_vgg.VGG19Network(input_shape=input_shape,
                                        input_tensor=input_tensor,
                                        include_top=include_top,
                                        pooling=pooling,
                                        classes=classes)
    elif model == inceptionv3:
        return network_InceptionV3.Inception_network_v3(input_shape=input_shape,
                                                        input_tensor=input_tensor,
                                                        include_top=include_top,
                                                        pooling=pooling,
                                                        classes=classes)
    elif model == nasnetmobile:
        return network_nasnet.NASNetMobileNetwork(input_shape=input_shape,
                                                  input_tensor=input_tensor,
                                                  include_top=include_top,
                                                  pooling=pooling,
                                                  classes=classes)
    elif model == nasnetlarge:
        return network_nasnet.NASNetLargeNetwork(input_shape=input_shape,
                                                 input_tensor=input_tensor,
                                                 include_top=include_top,
                                                 pooling=pooling,
                                                 classes=classes)
    elif model == resnet50v1:
        return network_resnet_common.ResNet50Network(input_shape=input_shape,
                                                     input_tensor=input_tensor,
                                                     include_top=include_top,
                                                     pooling=pooling,
                                                     classes=classes)
    elif model == resnet50v2:
        return network_resnet_common.ResNet50NetworkV2(input_shape=input_shape,
                                                       input_tensor=input_tensor,
                                                       include_top=include_top,
                                                       pooling=pooling,
                                                       classes=classes)
    elif model == resnet101v1:
        return network_resnet_common.ResNet101Network(input_shape=input_shape,
                                                      input_tensor=input_tensor,
                                                      include_top=include_top,
                                                      pooling=pooling,
                                                      classes=classes)
    elif model == resnet101v2:
        return network_resnet_common.ResNet101NetworkV2(input_shape=input_shape,
                                                        input_tensor=input_tensor,
                                                        include_top=include_top,
                                                        pooling=pooling,
                                                        classes=classes)
    elif model == resnet152v1:
        return network_resnet_common.ResNet152Network(input_shape=input_shape,
                                                      input_tensor=input_tensor,
                                                      include_top=include_top,
                                                      pooling=pooling,
                                                      classes=classes)
    elif model == resnet152v2:
        return network_resnet_common.ResNet152NetworkV2(input_shape=input_shape,
                                                        input_tensor=input_tensor,
                                                        include_top=include_top,
                                                        pooling=pooling,
                                                        classes=classes)
    elif model == resnext50:
        return network_resnet_common.ResNext50Network(input_shape=input_shape,
                                                      input_tensor=input_tensor,
                                                      include_top=include_top,
                                                      pooling=pooling,
                                                      classes=classes)
    elif model == resnext101:
        return network_resnet_common.ResNext101Network(input_shape=input_shape,
                                                       input_tensor=input_tensor,
                                                       include_top=include_top,
                                                       pooling=pooling,
                                                       classes=classes)
    elif model == xception:
        return network_xception.XceptionNetwork(input_shape=input_shape,
                                                input_tensor=input_tensor,
                                                include_top=include_top,
                                                pooling=pooling,
                                                classes=classes)
    elif model == densenet121:
        return network_densenet.DenseNet121Network(input_shape=input_shape,
                                                   input_tensor=input_tensor,
                                                   include_top=include_top,
                                                   pooling=pooling,
                                                   classes=classes)
    elif model == densenet169:
        return network_densenet.DenseNet169Network(input_shape=input_shape,
                                                   input_tensor=input_tensor,
                                                   include_top=include_top,
                                                   pooling=pooling,
                                                   classes=classes)
    elif model == densenet201:
        return network_densenet.DenseNet201Network(input_shape=input_shape,
                                                   input_tensor=input_tensor,
                                                   include_top=include_top,
                                                   pooling=pooling,
                                                   classes=classes)
    elif model == mobilenetv1:
        return network_mobilenet_v1.Mobilenet_v1_Network(input_shape=input_shape,
                                                         input_tensor=input_tensor,
                                                         include_top=include_top,
                                                         pooling=pooling,
                                                         classes=classes,
                                                         alpha=alpha, depth_multiplier=depth_multiplier)
    elif model == mobilenetv2:
        return network_mobilenet_v2.Mobilenet_v2_Network(input_shape=input_shape,
                                                         input_tensor=input_tensor,
                                                         include_top=include_top,
                                                         pooling=pooling,
                                                         classes=classes,
                                                         alpha=alpha, depth_multiplier=depth_multiplier)
    elif model == mobilenetsmallv3:
        return network_mobilenet_v3.Mobilenet_v3_small_Network(input_shape=input_shape,
                                                               input_tensor=input_tensor,
                                                               include_top=include_top,
                                                               pooling=pooling,
                                                               classes=classes,
                                                               alpha=alpha, minimalistic=False,
                                                               last_point_ch=1024, dropout_rate=0.2)
    elif model == mobilenetlargev3:
        return network_mobilenet_v3.Mobilenet_v3_large_Network(input_shape=input_shape,
                                                               input_tensor=input_tensor,
                                                               include_top=include_top,
                                                               pooling=pooling,
                                                               classes=classes,
                                                               alpha=alpha, minimalistic=False,
                                                               last_point_ch=1280, dropout_rate=0.2)
    elif model == efficientnetb0:
        return network_efficientnet.EfficientNetB0_Network(width_coefficient=1.0, depth_coefficient=1.0,
                                                           default_size=224, dropout_rate=0.2,
                                                           drop_connect_rate=0.2, depth_divisor=8,
                                                           activation='swish', blocks_args='default',
                                                           model_name='efficientnet_B0',
                                                           include_top=include_top,
                                                           input_tensor=input_tensor,
                                                           input_shape=input_shape,
                                                           pooling=pooling,
                                                           classes=classes)
    elif model == efficientnetb1:
        return network_efficientnet.EfficientNetB1_Network(width_coefficient=1.0, depth_coefficient=1.1,
                                                           default_size=240, dropout_rate=0.2,
                                                           drop_connect_rate=0.2, depth_divisor=8,
                                                           activation='swish', blocks_args='default',
                                                           model_name='efficientnet_B1',
                                                           include_top=include_top,
                                                           input_tensor=input_tensor,
                                                           input_shape=input_shape,
                                                           pooling=pooling,
                                                           classes=classes)
    elif model == efficientnetb2:
        return network_efficientnet.EfficientNetB2_Network(width_coefficient=1.1, depth_coefficient=1.2,
                                                           default_size=260, dropout_rate=0.3,
                                                           drop_connect_rate=0.2, depth_divisor=8,
                                                           activation='swish', blocks_args='default',
                                                           model_name='efficientnet_B2',
                                                           include_top=include_top,
                                                           input_tensor=input_tensor,
                                                           input_shape=input_shape,
                                                           pooling=pooling,
                                                           classes=classes)
    elif model == efficientnetb3:
        return network_efficientnet.EfficientNetB3_Network(width_coefficient=1.2, depth_coefficient=1.4,
                                                           default_size=300, dropout_rate=0.3,
                                                           drop_connect_rate=0.2, depth_divisor=8,
                                                           activation='swish', blocks_args='default',
                                                           model_name='efficientnet_B3',
                                                           include_top=include_top,
                                                           input_tensor=input_tensor,
                                                           input_shape=input_shape,
                                                           pooling=pooling,
                                                           classes=classes)
    elif model == efficientnetb4:
        return network_efficientnet.EfficientNetB4_Network(width_coefficient=1.4, depth_coefficient=1.8,
                                                           default_size=380, dropout_rate=0.4,
                                                           drop_connect_rate=0.2, depth_divisor=8,
                                                           activation='swish', blocks_args='default',
                                                           model_name='efficientnet_B4',
                                                           include_top=include_top,
                                                           input_tensor=input_tensor,
                                                           input_shape=input_shape,
                                                           pooling=pooling,
                                                           classes=classes)
    elif model == efficientnetb5:
        return network_efficientnet.EfficientNetB5_Network(width_coefficient=1.6, depth_coefficient=2.2,
                                                           default_size=456, dropout_rate=0.4,
                                                           drop_connect_rate=0.2, depth_divisor=8,
                                                           activation='swish', blocks_args='default',
                                                           model_name='efficientnet_B5',
                                                           include_top=include_top,
                                                           input_tensor=input_tensor,
                                                           input_shape=input_shape,
                                                           pooling=pooling,
                                                           classes=classes)
    elif model == efficientnetb6:
        return network_efficientnet.EfficientNetB6_Network(width_coefficient=1.8, depth_coefficient=2.6,
                                                           default_size=528, dropout_rate=0.5,
                                                           drop_connect_rate=0.2, depth_divisor=8,
                                                           activation='swish', blocks_args='default',
                                                           model_name='efficientnet_B6',
                                                           include_top=include_top,
                                                           input_tensor=input_tensor,
                                                           input_shape=input_shape,
                                                           pooling=pooling,
                                                           classes=classes)
    elif model == efficientnetb7:
        return network_efficientnet.EfficientNetB7_Network(width_coefficient=2.0, depth_coefficient=3.1,
                                                           default_size=600, dropout_rate=0.5,
                                                           drop_connect_rate=0.2, depth_divisor=8,
                                                           activation='swish', blocks_args='default',
                                                           model_name='efficientnet_B7',
                                                           include_top=include_top,
                                                           input_tensor=input_tensor,
                                                           input_shape=input_shape,
                                                           pooling=pooling,
                                                           classes=classes)
