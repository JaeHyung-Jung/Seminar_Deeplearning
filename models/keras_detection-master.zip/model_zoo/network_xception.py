from tensorflow.keras.layers import *
from tensorflow.keras.models import Model
from tensorflow.keras.regularizers import L2
from . import network_base


def conv2d_bn(x, filters, kernel_size, padding='same', strides=1, activation='relu', weight_decay=1e-5,):
    x = Conv2D(filters=filters, kernel_size=kernel_size, padding=padding,
               strides=strides, kernel_regularizer=L2(weight_decay))(x)
    x = BatchNormalization()(x)
    if activation:
        x = Activation(activation)(x)
    return x


def sepconv2d_bn(x, filters, kernel_size, padding='same', strides=1, activation='relu',
                 weight_decay=1e-5, depth_multiplier=1):
    x = SeparableConv2D(filters, kernel_size, padding=padding, strides=strides, depth_multiplier=depth_multiplier,
                        depthwise_regularizer=L2(weight_decay), pointwise_regularizer=L2(weight_decay))(x)
    x = BatchNormalization()(x)
    if activation:
        x = Activation(activation)(x)
    return x


class XceptionNetwork(network_base.BaseNetwork):
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling='avg', classes=2,
                 alpha=1, depth_multiplier=1):
        self.alpha = alpha
        self.depth_multiplier = depth_multiplier
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)

    def setup(self):
        img_input = self.get_input_tensor()
        x = conv2d_bn(img_input, 32, (3, 3), strides=2)  # (299, 299, 3) -> (150, 150, 32)
        x = conv2d_bn(x, 64, (3, 3))

        # Entry flow
        for filters in [128, 256, 728]:  # (75, 75, 64) -> (75, 75, 128) -> (38, 38, 256) -> (19, 19, 728)
            residual = conv2d_bn(x, filters, (1, 1), strides=2, activation=None)

            x = Activation(activation='relu')(x)
            x = sepconv2d_bn(x, filters, (3, 3))
            x = sepconv2d_bn(x, filters, (3, 3), activation=None)
            x = MaxPooling2D((3, 3), padding='same', strides=2)(x)

            x = Add()([x, residual])

        # Middle flow
        for i in range(8):  # (19, 19, 728)
            residual = x

            x = Activation(activation='relu')(x)
            x = sepconv2d_bn(x, 728, (3, 3))
            x = sepconv2d_bn(x, 728, (3, 3))
            x = sepconv2d_bn(x, 728, (3, 3), activation=None)

            x = Add()([x, residual])

        # Exit flow
        residual = conv2d_bn(x, 1024, (1, 1), strides=2, activation=None)  # (19, 19, 728) -> (10, 10, 1024)

        x = Activation(activation='relu')(x)
        x = sepconv2d_bn(x, 728, (3, 3))
        x = sepconv2d_bn(x, 1024, (3, 3), activation=None)  # (19, 19, 728) -> (19, 19, 1024)
        x = MaxPooling2D((3, 3), padding='same', strides=2)(x)  # (19, 19, 1024) -> (10, 10, 1024)

        x = Add()([x, residual])

        x = sepconv2d_bn(x, 1536, (3, 3))
        x = sepconv2d_bn(x, 2048, (3, 3))

        x = self.get_pool(x)
        if self.include_top:
            x = Dropout(0.5)(x)
            x = self.get_top_include(x)

            model = Model(img_input, x, name='Xception')
            return model
        else:
            return x
