"""
Readme :
    It focuses on "tf.Keras" Version (tf. 2.3.0)
    It's slightly different other architecture.
    If you have a question, feel free to ask.
"""
from tensorflow.keras.layers import *
from tensorflow.keras.models import Model
from . import network_base


def stem_conv_block(x, filters, alpha, kernel=(3, 3), strides=(1, 1)):
    filters = int(filters * alpha)
    x = ZeroPadding2D(padding=((0, 1), (0, 1)), name='conv1_pad')(x)
    x = Conv2D(filters, kernel, padding='valid', use_bias=False, strides=strides, name='conv1')(x)
    x = BatchNormalization(axis=3, name='conv1_bn')(x)
    x = ReLU(6., name='conv1_relu')(x)
    return x


def depthwise_conv_block(x, channels, alpha, depth_multiplier=1, strides=(1, 1), block_id=1):
    channels = int(channels * alpha)
    if strides != (1, 1):
        x = ZeroPadding2D(((0, 1), (0, 1)), name='conv_pad_%d' % block_id)(x)
    x = DepthwiseConv2D((3, 3), padding='same' if strides == (1, 1) else 'valid',
                        depth_multiplier=depth_multiplier,
                        strides=strides,
                        use_bias=False,
                        name='conv_dw_%d' % block_id)(x)
    x = BatchNormalization(axis=3, name='conv_dw_%d_bn' % block_id)(x)
    x = ReLU(6., name='conv_dw_%d_relu' % block_id)(x)
    x = Conv2D(channels, (1, 1), padding='same', use_bias=False, strides=(1, 1), name='conv_pw_%d' % block_id)(x)
    x = ReLU(6., name='conv_pw_%d_relu' % block_id)(x)
    return x


class Mobilenet_v1_Network(network_base.BaseNetwork):
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling='avg', classes=2,
                 alpha=1, depth_multiplier=1):
        self.alpha = alpha
        self.depth_multiplier = depth_multiplier
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)

    def setup(self):
        img_input = self.get_input_tensor()
        x = stem_conv_block(img_input, 32, self.alpha, strides=(2, 2))

        x = depthwise_conv_block(x, channels=64, alpha=self.alpha,
                                 depth_multiplier=self.depth_multiplier, block_id=1)
        for i in range(2, 7, 2):
            channel = 2 ** ((i//2) + 6)
            x = depthwise_conv_block(x, channels=channel, alpha=self.alpha,
                                     depth_multiplier=self.depth_multiplier, strides=(2, 2), block_id=i)
            x = depthwise_conv_block(x, channels=channel, alpha=self.alpha,
                                     depth_multiplier=self.depth_multiplier, block_id=i+1)
        for i in range(8, 12):
            x = depthwise_conv_block(x, channels=512, alpha=self.alpha,
                                     depth_multiplier=self.depth_multiplier, block_id=i)
        x = depthwise_conv_block(x, 1024, alpha=self.alpha,
                                 depth_multiplier=self.depth_multiplier, strides=(2, 2), block_id=12)
        x = depthwise_conv_block(x, 1024, alpha=self.alpha,
                                 depth_multiplier=self.depth_multiplier, block_id=13)
        x = self.get_pool(x)  # Global avg
        if self.include_top:
            # x = super().get_top_include(x)  # If I use dense(#classes , softmax) layer directly...
            x = self.get_top_include(x)

            model = Model(img_input, x, name='Mobilenet_v1')
            return model
        else:
            return x

    def get_top_include(self, x):
        x = Reshape((1, 1, int(1024 * self.alpha)), name='reshape_1')(x)
        x = Dropout(1e-3, name='dropout')(x)
        x = Conv2D(self.classes, (1, 1), padding='same', name='conv_preds')(x)
        x = Reshape((self.classes,), name='reshape_2')(x)
        x = Activation('softmax', name='act_softmax')(x)
        return x
