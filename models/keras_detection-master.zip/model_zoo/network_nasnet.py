from tensorflow.keras.layers import *
from tensorflow.keras.models import Model
from tensorflow.keras import backend as K
from . import network_base


def correct_pad(inputs, kernel_size):
    img_dim = 2 if K.image_data_format() == 'channels_first' else 1
    input_size = K.int_shape(inputs)[img_dim:(img_dim + 2)]
    if isinstance(kernel_size, int):
        kernel_size = (kernel_size, kernel_size)
    if input_size[0] is None:
        adjust = (1, 1)
    else:
        adjust = (1 - input_size[0] % 2, 1 - input_size[1] % 2)
    correct = (kernel_size[0] // 2, kernel_size[1] // 2)
    return ((correct[0] - adjust[0], correct[0]),
            (correct[1] - adjust[1], correct[1]))


def _separable_conv_block(ip, filters, kernel_size=(3, 3), strides=(1, 1), block_id=None):
    channel_dim = 1 if K.image_data_format() == 'channels_first' else -1

    with K.name_scope('separable_conv_block_%s' % block_id):
        x = Activation('relu')(ip)
        if strides == (2, 2):
            x = ZeroPadding2D(
                padding=correct_pad(x, kernel_size),
                name='separable_conv_1_pad_%s' % block_id)(x)
            conv_pad = 'valid'
        else:
            conv_pad = 'same'
        x = SeparableConv2D(filters, kernel_size, strides=strides, name='separable_conv_1_%s' % block_id,
                            padding=conv_pad, use_bias=False, kernel_initializer='he_normal')(x)
        x = BatchNormalization(axis=channel_dim, momentum=0.9997, epsilon=1e-3, name='separable_conv_1_bn_%s' % block_id)(x)
        x = Activation('relu')(x)
        x = SeparableConv2D(filters, kernel_size, name='separable_conv_2_%s' % block_id, padding='same',
                            use_bias=False, kernel_initializer='he_normal')(x)
        x = BatchNormalization(axis=channel_dim, momentum=0.9997, epsilon=1e-3, name='separable_conv_2_bn_%s' % block_id)(x)
    return x


def _adjust_block(p, ip, filters, block_id=None):
    channel_dim = 1 if K.image_data_format() == 'channels_first' else -1
    img_dim = 2 if K.image_data_format() == 'channels_first' else -2
    ip_shape = K.int_shape(ip)

    if p is not None:
        p_shape = K.int_shape(p)

    with K.name_scope('adjust_block'):
        if p is None:
            p = ip

        elif p_shape[img_dim] != ip_shape[img_dim]:
            with K.name_scope('adjust_reduction_block_%s' % block_id):
                p = Activation('relu', name='adjust_relu_1_%s' % block_id)(p)
                p1 = AveragePooling2D((1, 1), strides=(2, 2), padding='valid', name='adjust_avg_pool_1_%s' % block_id)(p)
                p1 = Conv2D(filters // 2, (1, 1), padding='same', use_bias=False,
                            name='adjust_conv_1_%s' % block_id, kernel_initializer='he_normal')(p1)

                p2 = ZeroPadding2D(padding=((0, 1), (0, 1)))(p)
                p2 = Cropping2D(cropping=((1, 0), (1, 0)))(p2)
                p2 = AveragePooling2D((1, 1), strides=(2, 2), padding='valid', name='adjust_avg_pool_2_%s' % block_id)(p2)
                p2 = Conv2D(filters // 2, (1, 1), use_bias=False,
                            name='adjust_conv_2_%s' % block_id, kernel_initializer='he_normal')(p2)

                p = concatenate([p1, p2], axis=channel_dim)
                p = BatchNormalization(axis=channel_dim, momentum=0.9997, epsilon=1e-3, name='adjust_bn_%s' % block_id)(p)

        elif p_shape[channel_dim] != filters:
            with K.name_scope('adjust_projection_block_%s' % block_id):
                p = Activation('relu')(p)
                p = Conv2D(filters, (1, 1), strides=(1, 1), padding='same', name='adjust_conv_projection_%s' % block_id,
                           use_bias=False, kernel_initializer='he_normal')(p)
                p = BatchNormalization(axis=channel_dim, momentum=0.9997, epsilon=1e-3, name='adjust_bn_%s' % block_id)(p)
    return p


def _normal_a_cell(ip, p, filters, block_id=None):
    channel_dim = 1 if K.image_data_format() == 'channels_first' else -1

    with K.name_scope('normal_A_block_%s' % block_id):
        p = _adjust_block(p, ip, filters, block_id)

        h = Activation('relu')(ip)
        h = Conv2D(filters, (1, 1), strides=(1, 1), padding='same', name='normal_conv_1_%s' % block_id,
                   use_bias=False, kernel_initializer='he_normal')(h)
        h = BatchNormalization(axis=channel_dim, momentum=0.9997, epsilon=1e-3, name='normal_bn_1_%s' % block_id)(h)

        with K.name_scope('block_1'):
            x1_1 = _separable_conv_block(h, filters, kernel_size=(5, 5), block_id='normal_left1_%s' % block_id)
            x1_2 = _separable_conv_block(p, filters, block_id='normal_right1_%s' % block_id)
            x1 = add([x1_1, x1_2], name='normal_add_1_%s' % block_id)

        with K.name_scope('block_2'):
            x2_1 = _separable_conv_block(p, filters, (5, 5), block_id='normal_left2_%s' % block_id)
            x2_2 = _separable_conv_block(p, filters, (3, 3), block_id='normal_right2_%s' % block_id)
            x2 = add([x2_1, x2_2], name='normal_add_2_%s' % block_id)

        with K.name_scope('block_3'):
            x3 = AveragePooling2D((3, 3), strides=(1, 1), padding='same', name='normal_left3_%s' % block_id)(h)
            x3 = add([x3, p], name='normal_add_3_%s' % block_id)

        with K.name_scope('block_4'):
            x4_1 = AveragePooling2D((3, 3), strides=(1, 1), padding='same', name='normal_left4_%s' % block_id)(p)
            x4_2 = AveragePooling2D((3, 3), strides=(1, 1), padding='same', name='normal_right4_%s' % block_id)(p)
            x4 = add([x4_1, x4_2], name='normal_add_4_%s' % block_id)

        with K.name_scope('block_5'):
            x5 = _separable_conv_block(h, filters, block_id='normal_left5_%s' % block_id)
            x5 = add([x5, h], name='normal_add_5_%s' % block_id)

        x = concatenate([p, x1, x2, x3, x4, x5], axis=channel_dim, name='normal_concat_%s' % block_id)
    return x, ip


def _reduction_a_cell(ip, p, filters, block_id=None):
    channel_dim = 1 if K.image_data_format() == 'channels_first' else -1
    with K.name_scope('reduction_A_block_%s' % block_id):
        p = _adjust_block(p, ip, filters, block_id)

        h = Activation('relu')(ip)
        h = Conv2D(filters, (1, 1), strides=(1, 1), padding='same', name='reduction_conv_1_%s' % block_id,
                   use_bias=False, kernel_initializer='he_normal')(h)
        h = BatchNormalization(axis=channel_dim, momentum=0.9997, epsilon=1e-3, name='reduction_bn_1_%s' % block_id)(h)
        h3 = ZeroPadding2D(padding=correct_pad(h, (3, 3)), name='reduction_pad_1_%s' % block_id)(h)

        with K.name_scope('block_1'):
            x1_1 = _separable_conv_block(h, filters, (5, 5), strides=(2, 2), block_id='reduction_left1_%s' % block_id)
            x1_2 = _separable_conv_block(p, filters, (7, 7), strides=(2, 2), block_id='reduction_right1_%s' % block_id)
            x1 = add([x1_1, x1_2], name='reduction_add_1_%s' % block_id)

        with K.name_scope('block_2'):
            x2_1 = MaxPooling2D((3, 3), strides=(2, 2), padding='valid', name='reduction_left2_%s' % block_id)(h3)
            x2_2 = _separable_conv_block(p, filters, (7, 7), strides=(2, 2), block_id='reduction_right2_%s' % block_id)
            x2 = add([x2_1, x2_2], name='reduction_add_2_%s' % block_id)

        with K.name_scope('block_3'):
            x3_1 = AveragePooling2D((3, 3), strides=(2, 2), padding='valid', name='reduction_left3_%s' % block_id)(h3)
            x3_2 = _separable_conv_block(p, filters, (5, 5), strides=(2, 2), block_id='reduction_right3_%s' % block_id)
            x3 = add([x3_1, x3_2], name='reduction_add3_%s' % block_id)

        with K.name_scope('block_4'):
            x4 = AveragePooling2D((3, 3), strides=(1, 1), padding='same', name='reduction_left4_%s' % block_id)(x1)
            x4 = add([x2, x4])

        with K.name_scope('block_5'):
            x5_1 = _separable_conv_block(x1, filters, (3, 3), block_id='reduction_left4_%s' % block_id)
            x5_2 = MaxPooling2D((3, 3), strides=(2, 2), padding='valid', name='reduction_right5_%s' % block_id)(h3)
            x5 = add([x5_1, x5_2], name='reduction_add4_%s' % block_id)

        x = concatenate([x2, x3, x4, x5], axis=channel_dim, name='reduction_concat_%s' % block_id)
        return x, ip


class NASNetBaseNetwork(network_base.BaseNetwork):
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling=None, classes=2,
                 penultimate_filters=4032, num_blocks=6, stem_block_filters=96, skip_reduction=True, filter_multiplier=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)
        self.penultimate_filters = penultimate_filters
        self.num_blocks = num_blocks
        self.stem_block_filters = stem_block_filters
        self.skip_reduction = skip_reduction
        self.filter_multiplier = filter_multiplier

    def setup(self):
        img_input = self.get_input_tensor()
        if self.penultimate_filters % (24 * (self.filter_multiplier ** 2)) != 0:
            raise ValueError(
                'For NASNet-A models, the `penultimate_filters` must be a multiple '
                'of 24 * (`filter_multiplier` ** 2). Current value: %d' %
                self.penultimate_filters)

        channel_dim = 1 if K.image_data_format() == 'channels_first' else -1
        filters = self.penultimate_filters // 24

        x = Conv2D(self.stem_block_filters, (3, 3), strides=(2, 2), padding='valid',
                   use_bias=False, name='stem_conv1', kernel_initializer='he_normal')(img_input)
        x = BatchNormalization(axis=channel_dim, momentum=0.9997, epsilon=1e-3, name='stem_bn1')(x)
        p = None
        x, p = _reduction_a_cell(x, p, filters // (self.filter_multiplier ** 2),
                                 block_id='stem_1')
        x, p = _reduction_a_cell(x, p, filters // self.filter_multiplier,
                                 block_id='stem_2')

        for i in range(self.num_blocks):
            x, p = _normal_a_cell(x, p, filters, block_id='%d' % i)

        x, p0 = _reduction_a_cell(x, p, filters * self.filter_multiplier,
                                  block_id='reduce_%d' % self.num_blocks)

        p = p0 if not self.skip_reduction else p

        for i in range(self.num_blocks):
            x, p = _normal_a_cell(x, p, filters * self.filter_multiplier,
                                  block_id='%d' % (self.num_blocks + i + 1))

        x, p0 = _reduction_a_cell(x, p, filters * self.filter_multiplier ** 2,
                                  block_id='reduce_%d' % (2 * self.num_blocks))

        p = p0 if not self.skip_reduction else p

        for i in range(self.num_blocks):
            x, p = _normal_a_cell(x, p, filters * self.filter_multiplier ** 2,
                                  block_id='%d' % (2 * self.num_blocks + i + 1))

        x = Activation('relu')(x)
        x = self.get_pool(x)
        if self.include_top:
            x = self.get_top_include(x)
            model = Model(img_input, x, name='NasNet')
            return model
        else:
            return x


class NASNetLargeNetwork(NASNetBaseNetwork):
    """Default Input is (331, 331, 3) (331, 331, 3) """
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling=None, classes=2,
                 penultimate_filters=4032, num_blocks=6, stem_block_filters=96, skip_reduction=True, filter_multiplier=2):
        NASNetBaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)
        self.penultimate_filters = penultimate_filters
        self.num_blocks = num_blocks
        self.stem_block_filters = stem_block_filters
        self.skip_reduction = skip_reduction
        self.filter_multiplier = filter_multiplier


class NASNetMobileNetwork(NASNetBaseNetwork):
    """ Default Input is (224, 224, 3) """
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling=None, classes=2,
                 penultimate_filters=1056, num_blocks=4, stem_block_filters=32, skip_reduction=False, filter_multiplier=2):
        NASNetBaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)
        self.penultimate_filters = penultimate_filters
        self.num_blocks = num_blocks
        self.stem_block_filters = stem_block_filters
        self.skip_reduction = skip_reduction
        self.filter_multiplier = filter_multiplier

