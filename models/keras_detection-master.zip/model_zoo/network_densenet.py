from tensorflow.keras.layers import *
from tensorflow.keras.models import Model
from tensorflow.keras import backend as K
from . import network_base


def dense_block(x, blocks, name):
    for i in range(blocks):
        x = conv_block(x, 32, name=name + '_block' + str(i + 1))
    return x


def transition_block(x, reduction, name):
    bn_axis = 3
    x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name=name + '_bn')(x)
    x = Activation('relu', name=name + '_relu')(x)
    x = Conv2D(int(K.int_shape(x)[bn_axis] * reduction), 1, use_bias=False, name=name + '_conv')(x)
    x = AveragePooling2D(2, strides=2, name=name + '_pool')(x)
    return x


def conv_block(x, growth_rate, name):
    bn_axis = 3
    x1 = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name=name + '_0_bn')(x)
    x1 = Activation('relu', name=name + '_0_relu')(x1)

    x1 = Conv2D(4 * growth_rate, 1, use_bias=False, name=name + '_1_conv')(x1)
    x1 = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name=name + '_1_bn')(x1)
    x1 = Activation('relu', name=name + '_1_relu')(x1)

    x1 = Conv2D(growth_rate, 3, padding='same', use_bias=False, name=name + '_2_conv')(x1)
    x = Concatenate(axis=bn_axis, name=name + '_concat')([x, x1])
    return x


def stem_block(x):
    bn_axis = 3
    x = ZeroPadding2D(padding=((3, 3), (3, 3)))(x)
    x = Conv2D(64, 7, strides=2, use_bias=False, name='conv1/conv')(x)
    x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name='conv1/bn')(x)
    x = Activation('relu', name='conv1/relu')(x)
    x = ZeroPadding2D(padding=((1, 1), (1, 1)))(x)
    x = MaxPooling2D(3, strides=2, name='pool1')(x)
    return x


class DensenetBaseNetwork(network_base.BaseNetwork):
    def __init__(self, include_top=True, input_tensor=None, input_shape=None, pooling=None, classes=2):
        network_base.BaseNetwork.__init__(self, include_top, input_tensor, input_shape, pooling, classes)


class DenseNet121Network(DensenetBaseNetwork):
    def setup(self):
        bn_axis = 3
        img_input = self.get_input_tensor()

        x = stem_block(img_input)
        x = dense_block(x, 6, name='conv2')
        x = transition_block(x, 0.5, name='pool2')
        x = dense_block(x, 12, name='conv3')
        x = transition_block(x, 0.5, name='pool3')
        x = dense_block(x, 24, name='conv4')
        x = transition_block(x, 0.5, name='pool4')
        x = dense_block(x, 16, name='conv5')
        x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name='bn')(x)
        x = Activation('relu', name='relu')(x)

        x = self.get_pool(x)
        if self.include_top:
            x = self.get_top_include(x)
            model = Model(img_input, x, name='DenseNet121')
            return model
        else:
            return x


class DenseNet169Network(DensenetBaseNetwork):
    def setup(self):
        bn_axis = 3
        img_input = self.get_input_tensor()

        x = stem_block(img_input)
        x = dense_block(x, 6, name='conv2')
        x = transition_block(x, 0.5, name='pool2')
        x = dense_block(x, 12, name='conv3')
        x = transition_block(x, 0.5, name='pool3')
        x = dense_block(x, 32, name='conv4')
        x = transition_block(x, 0.5, name='pool4')
        x = dense_block(x, 32, name='conv5')
        x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name='bn')(x)
        x = Activation('relu', name='relu')(x)

        x = self.get_pool(x)
        if self.include_top:
            x = self.get_top_include(x)
            model = Model(img_input, x, name='DenseNet169')
            return model
        else:
            return x


class DenseNet201Network(DensenetBaseNetwork):
    def setup(self):
        bn_axis = 3
        img_input = self.get_input_tensor()

        x = stem_block(img_input)
        x = dense_block(x, 6, name='conv2')
        x = transition_block(x, 0.5, name='pool2')
        x = dense_block(x, 12, name='conv3')
        x = transition_block(x, 0.5, name='pool3')
        x = dense_block(x, 48, name='conv4')
        x = transition_block(x, 0.5, name='pool4')
        x = dense_block(x, 32, name='conv5')
        x = BatchNormalization(axis=bn_axis, epsilon=1.001e-5, name='bn')(x)
        x = Activation('relu', name='relu')(x)

        x = self.get_pool(x)
        if self.include_top:
            x = self.get_top_include(x)
            model = Model(img_input, x, name='DenseNet201')
            return model
        else:
            return x