import numpy as np
from . import data_generators
import copy


def calc_iou(R, img_data, configure, class_mapping):
    bboxes = img_data['bboxes']
    (width, height) = (img_data['width'], img_data['height'])
    (resized_width, resized_height) = data_generators.get_new_img_size(width, height, configure.im_size)

    gta = np.zeros((len(bboxes), 4))
    for bbox_idx, bbox in enumerate(bboxes):  # Initial # ground truth boxes information
        gta[bbox_idx, 0] = int(round(bbox['x1'] * (resized_width / float(width)) / configure.rpn_stride))
        gta[bbox_idx, 1] = int(round(bbox['x2'] * (resized_width / float(width)) / configure.rpn_stride))
        gta[bbox_idx, 2] = int(round(bbox['y1'] * (resized_height / float(height)) / configure.rpn_stride))
        gta[bbox_idx, 3] = int(round(bbox['y2'] * (resized_height / float(height)) / configure.rpn_stride))

    x_roi = []
    y_class_num = []
    y_class_regression_coordinates = []
    y_class_regression_label = []
    IoUs = []

    for idx in range(R.shape[0]):  # Fisrt R returns bbox, Second R returns Prob
        (x1, y1, x2, y2) = R[idx, :]
        x1 = int(round(x1))
        y1 = int(round(y1))
        x2 = int(round(x2))
        y2 = int(round(y2))

        best_iou = 0.0
        best_bbox_idx = -1
        for bbox_idx in range(len(bboxes)):
            curr_iou = data_generators.iou([gta[bbox_idx, 0], gta[bbox_idx, 1], gta[bbox_idx, 2], gta[bbox_idx, 3]], [x1, y1, x2, y2])
            if curr_iou > best_iou:
                best_iou = curr_iou
                best_bbox_idx = bbox_idx

        if best_iou < configure.classifier_min_overlap: continue
        else:
            w = x2 - x1
            h = y2 - y1
            x_roi.append([x1, y1, w, h])
            IoUs.append(best_iou)

            if configure.classifier_min_overlap <= best_iou < configure.classifier_max_overlap:
                class_name = 'bg'
            elif configure.classifier_max_overlap <= best_iou:
                class_name = bboxes[best_bbox_idx]['class']
                cxg = (gta[best_bbox_idx, 0] + gta[best_bbox_idx, 1]) / 2.0
                cyg = (gta[best_bbox_idx, 2] + gta[best_bbox_idx, 3]) / 2.0
                cx = x1 + w / 2.0
                cy = y1 + h / 2.0
                tx = (cxg - cx) / float(w)
                ty = (cyg - cy) / float(h)
                tw = np.log((gta[best_bbox_idx, 1] - gta[best_bbox_idx, 0]) / float(w))
                th = np.log((gta[best_bbox_idx, 3] - gta[best_bbox_idx, 2]) / float(h))
            else:
                print('roi = {}'.format(best_iou))
                raise RuntimeError

        class_num = class_mapping[class_name]
        class_label = len(class_mapping) * [0]
        class_label[class_num] = 1
        y_class_num.append(copy.deepcopy(class_label))  # label_encoded e.g. one figure [1, 0, 1, ... , 0, 0] (#21)
        coordinates = [0] * 4 * (len(class_mapping) - 1)  # [0, 0, 0, 0] X (4*20)
        labels = [0] * 4 * (len(class_mapping) - 1)   # [0, 0, 0, 0] X (4*20)
        if class_name != 'bg':
            label_pos = 4 * class_num
            sx, sy, sw, sh = configure.classifier_regr_std  # [8.0, 8.0, 4.0, 4.0] scaled
            coordinates[label_pos: label_pos + 4] = [sx * tx, sy * ty, sw * tw, sh * th]
            labels[label_pos: label_pos + 4] = [1, 1, 1, 1]
        y_class_regression_coordinates.append(copy.deepcopy(coordinates))
        y_class_regression_label.append(copy.deepcopy(labels))

    if len(x_roi) == 0:
        return None, None, None, None

    X = np.array(x_roi)
    Y1 = np.array(y_class_num)
    Y2 = np.concatenate([np.array(y_class_regression_label), np.array(y_class_regression_coordinates)], axis=1)

    return np.expand_dims(X, axis=0), \
           np.expand_dims(Y1, axis=0).astype('float32'), \
           np.expand_dims(Y2, axis=0).astype('float32'), \
           IoUs


def non_max_suppression_fast(boxes, probs, overlap_thresh=0.9, max_boxes=300):
    if len(boxes) == 0:
        return []
    x1 = boxes[:, 0]
    y1 = boxes[:, 1]
    x2 = boxes[:, 2]
    y2 = boxes[:, 3]
    if boxes.dtype.kind == "i":
        boxes = boxes.astype("float")
    pick = []
    area = (x2 - x1) * (y2 - y1)
    idxs = np.argsort(probs)  # returns sorted index (not value)
    while len(idxs) > 0:
        last = len(idxs) - 1
        i = idxs[last]          # Stack_structure(pop maximum value)
        pick.append(i)

        xx1_int = np.maximum(x1[i], x1[idxs[:last]])
        yy1_int = np.maximum(y1[i], y1[idxs[:last]])
        xx2_int = np.minimum(x2[i], x2[idxs[:last]])
        yy2_int = np.minimum(x2[i], y2[idxs[:last]])

        ww_int = np.maximum(0, xx2_int - xx1_int)
        hh_int = np.maximum(0, yy2_int - yy1_int)

        area_int = ww_int * hh_int
        area_union = area[i] + area[idxs[:last]] - area_int
        overlap = area_int / (area_union + 1e-6)
        idxs = np.delete(idxs, np.concatenate([[last], np.where(overlap > overlap_thresh)[0]]))
        if len(pick) >= max_boxes:
            break

    boxes = boxes[pick].astype("int")
    probs = probs[pick]
    return boxes, probs


def apply_reg_np(X, T):
    try:
        x = X[0, :, :]
        y = X[1, :, :]
        w = X[2, :, :]
        h = X[3, :, :]

        tx = T[0, :, :]
        ty = T[1, :, :]
        tw = T[2, :, :]
        th = T[3, :, :]

        cx = x + w / 2.
        cy = y + h / 2.
        cx1 = tx * w + cx
        cy1 = ty * h + cy

        w1 = np.exp(tw.astype(np.float64)) * w
        h1 = np.exp(th.astype(np.float64)) * h
        x1 = cx1 - w1/2.
        y1 = cy1 - h1/2.

        x1 = np.round(x1)
        y1 = np.round(y1)
        w1 = np.round(w1)
        h1 = np.round(h1)
        return np.stack([x1, y1, w1, h1])
    except Exception as e:
        print(e)
        return X


def rpn2roi(rpn_classify_layer, rpn_regression_layer, configure, backend, use_reg=True, max_boxes=300, overlap_thresh=0.9):
    rpn_regression_layer = rpn_regression_layer / configure.std_scaling
    anchor_sizes = configure.anchor_box_scales
    anchor_ratios = configure.anchor_box_ratios

    if backend == 'channels_first':
        (rows, cols) = rpn_classify_layer.shape[2:]
        A = np.zeros((4, rpn_classify_layer.shape[2], rpn_classify_layer.shape[3], rpn_classify_layer.shape[1]))

    elif backend == 'channels_last':
        (rows, cols) = rpn_classify_layer.shape[1:3]
        A = np.zeros((4, rpn_classify_layer.shape[1], rpn_classify_layer.shape[2], rpn_classify_layer.shape[3]))

    curr_layer = 0
    for anchor_size in anchor_sizes:
        for anchor_ratio in anchor_ratios:
            anchor_x = (anchor_size * anchor_ratio[0]) / configure.rpn_stride
            anchor_y = (anchor_size * anchor_ratio[1]) / configure.rpn_stride
            if backend =='channels_first':
                regression_parts = rpn_regression_layer[0, 4 * curr_layer: 4 * curr_layer + 4, :, :]
            else:
                regression_parts = rpn_regression_layer[0, :, :, 4 * curr_layer: 4 * curr_layer + 4]
                regression_parts = np.transpose(regression_parts, (2, 0, 1))

            X, Y = np.meshgrid(np.arange(cols), np.arange(rows))

            A[0, :, :, curr_layer] = X - anchor_x / 2
            A[1, :, :, curr_layer] = Y - anchor_y / 2
            A[2, :, :, curr_layer] = anchor_x
            A[3, :, :, curr_layer] = anchor_y

            if use_reg:
                A[:, :, :, curr_layer] = apply_reg_np(A[:, :, :, curr_layer], regression_parts)

            A[2, :, :, curr_layer] = np.maximum(1, A[2, :, :, curr_layer])
            A[3, :, :, curr_layer] = np.maximum(1, A[3, :, :, curr_layer])
            A[2, :, :, curr_layer] += A[0, :, :, curr_layer]
            A[3, :, :, curr_layer] += A[1, :, :, curr_layer]

            A[0, :, :, curr_layer] = np.maximum(0, A[0, :, :, curr_layer])
            A[1, :, :, curr_layer] = np.maximum(0, A[1, :, :, curr_layer])
            A[2, :, :, curr_layer] = np.minimum(cols-1, A[2, :, :, curr_layer])
            A[3, :, :, curr_layer] = np.minimum(rows-1, A[3, :, :, curr_layer])

            curr_layer += 1

    all_boxes = np.reshape(A.transpose((0, 3, 1, 2)), (4, -1)).transpose((1, 0))
    all_probs = rpn_classify_layer.transpose((0, 3, 1, 2)).reshape((-1))

    x1 = all_boxes[:, 0]
    y1 = all_boxes[:, 1]
    x2 = all_boxes[:, 2]
    y2 = all_boxes[:, 3]
    idxs = np.where((x1 - x2 >= 0) | (y1 - y2 >= 0))
    all_boxes = np.delete(all_boxes, idxs, 0)
    all_probs = np.delete(all_probs, idxs, 0)
    result = non_max_suppression_fast(all_boxes, all_probs, overlap_thresh=overlap_thresh, max_boxes=max_boxes)[0]
    return result
