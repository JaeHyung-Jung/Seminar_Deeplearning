import os
import cv2
import sys
import pprint
import random

from tqdm import tqdm
import numpy as np
from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw

"""
VisDroneDetection : 
 <bbox_left>,<bbox_top>,<bbox_width>,<bbox_height>,<score>,<object_category>,<truncation>,<occlusion>

Also class_labels :
 ignored regions(0), pedestrian(1), people(2), bicycle(3), car(4), 
 van(5), truck(6), tricycle(7), awning-tricycle(8), bus(9), motor(10), others(11)
"""

txt_input = './../datasets/VisDrone2019'
random.seed(777)

IMAGE_FOLDER = "images"
ANNOTATIONS_FOLDER = "annotations"

def get_data(input_path=txt_input):
    all_imgs = []
    classes_count = {}
    class_mapping = {}
    visualise = True
    _, dirs, _ = next(os.walk(input_path))
    for di in dirs:
        dataset_path = os.path.join(input_path, di)
        ann_root, _, ann_files = next(os.walk(os.path.join(dataset_path, ANNOTATIONS_FOLDER)))
        img_root, _, img_files = next(os.walk(os.path.join(dataset_path, IMAGE_FOLDER)))
        zip_files = tqdm(zip(ann_files, img_files), desc='Progress : ')
        for (ann_file, img_file) in zip_files:
            filename = os.path.join(img_root, img_file)
            if filename not in all_imgs:
                annotation_data = {'filepath': filename,
                                   'width': None,
                                   'height': None,
                                   'bboxes': []}
                if 'train' in di:
                    annotation_data['imageset'] = 'train'
                elif 'val' in di:
                    annotation_data['imageset'] = 'val'
                elif 'test' in di:
                    annotation_data['imageset'] = 'test'
                else:
                    print("Check other Folders")
                with open(os.path.join(ann_root, ann_file)) as f:
                    for line in f:
                        data = line.strip().split(',')
                        x1 = int(data[0])
                        y1 = int(data[1])
                        x2 = x1 + int(data[2])
                        y2 = y1 + int(data[3])
                        class_name = data[5]

                        if class_name not in classes_count:
                            classes_count[class_name] = 1
                        else:
                            classes_count[class_name] += 1

                        if class_name not in class_mapping:
                            class_mapping[class_name] = len(class_mapping)
                        annotation_data['bboxes'].append({
                            'class': class_name, 'x1': int(x1), 'x2': int(x2), 'y1': int(y1), 'y2': int(y2)})
            all_imgs.append(annotation_data)
    if 'bg' not in classes_count:
        classes_count['bg'] = 0
        class_mapping['bg'] = len(class_mapping)

    if visualise:
        img = cv2.imread(annotation_data['filepath'])
        for bbox in annotation_data['bboxes']:
            x_center = (bbox['x1'] + bbox['x2']) // 2
            y_center = (bbox['y1'] + bbox['y2']) // 2
            if bbox['class'] in '12':
                cv2.rectangle(img, (bbox['x1'], bbox['y1']), (bbox['x2'], bbox['y2']), (255, 0, 0))
            elif (bbox['class'] in '3456789') or (bbox['class'] == '10'):
                cv2.rectangle(img, (bbox['x1'], bbox['y1']), (bbox['x2'], bbox['y2']), (0, 0, 255))
            else:
                cv2.rectangle(img, (bbox['x1'], bbox['y1']), (bbox['x2'], bbox['y2']), (255, 255, 255))
            # cv2.putText(img, bbox['class'], (x_center, y_center), cv2.FONT_ITALIC, 1, (0, 0, 0), 2)
        cv2.imshow('img', img)
        cv2.waitKey(0)
    print("Parse is done !")
    random.shuffle(all_imgs)
    return all_imgs, classes_count, class_mapping

if __name__ == '__main__':
    all_imgs, classes_count, class_mapping = get_data()
