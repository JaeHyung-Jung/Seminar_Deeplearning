import os
import cv2
import xml.etree.ElementTree as ET
from tqdm import tqdm
import pprint
import random

voc_input = './../datasets/VOC2012'
random.seed(777)


# all_imgs(path, w, h, bbox(4), cls, tr/te, idx), classes_count(each count of classes), class_mapping(labels)
def get_data(input_path=voc_input):
    all_imgs = []
    classes_count = {}
    class_mapping = {}

    # parsing 정보 확인 Flag
    visualise = False
    print('Parsing annotation files : ', input_path)
    annot_path = os.path.join(input_path, 'Annotations')
    imgs_path = os.path.join(input_path, 'JPEGImages')

    images_path_train = os.path.join(input_path, 'ImageSets', 'Main', 'train.txt')
    images_path_val = os.path.join(input_path, 'ImageSets', 'Main', 'val.txt')
    images_path_test = os.path.join(input_path, 'ImageSets', 'Main', 'test.txt')

    train_files = []
    val_files = []
    test_files = []

    with open(images_path_train) as f:
        for line in f:
            train_files.append(line.strip() + '.jpg')

    with open(images_path_val) as f:
        for line in f:
            val_files.append(line.strip() + '.jpg')

    # test-set not included in pascal VOC 2012
    if os.path.isfile(images_path_test):
        with open(images_path_test) as f:
            for line in f:
                test_files.append(line.strip() + '.jpg')

    # annotation 파일 read : lines 17125 in there.
    annots = [os.path.join(annot_path, s) for s in os.listdir(annot_path)]
    annots = tqdm(annots)
    for idx, annot in enumerate(annots, start=1):
        exist_flag = False
        annots.set_description("Processing %s" % annot.split(os.sep)[-1])
        et = ET.parse(annot)
        element = et.getroot()

        element_objs = element.findall('object')

        element_filename = element.find('filename').text
        element_width = int(element.find('size').find('width').text)
        element_height = int(element.find('size').find('height').text)

        if len(element_objs) > 0:
            annotation_data = {'filepath': os.path.join(imgs_path, element_filename),
                               'width': element_width,
                               'height': element_height,
                               'bboxes': [],
                               'image_id': idx}

            if element_filename in train_files:
                annotation_data['imageset'] = 'train'
                exist_flag = True

            if element_filename in val_files:
                annotation_data['imageset'] = 'val'
                exist_flag = True

            if len(test_files) > 0:
                if element_filename in test_files:
                    annotation_data['imageset'] = 'test'
                    exist_flag = True

        # annotation file not exist in ImageSet
        if not exist_flag:
            continue

        for element_obj in element_objs:
            class_name = element_obj.find('name').text
            if class_name not in classes_count:
                classes_count[class_name] = 1
            else:
                classes_count[class_name] += 1

            # class mapping
            if class_name not in class_mapping:
                class_mapping[class_name] = len(class_mapping)

            obj_bbox = element_obj.find('bndbox')
            x1 = int(round(float(obj_bbox.find('xmin').text)))
            y1 = int(round(float(obj_bbox.find('ymin').text)))
            x2 = int(round(float(obj_bbox.find('xmax').text)))
            y2 = int(round(float(obj_bbox.find('ymax').text)))
            difficulty = int(element_obj.find('difficult').text) == 1
            annotation_data['bboxes'].append(
                {'class': class_name, 'x1': x1, 'x2': x2, 'y1': y1, 'y2': y2, 'difficult': difficulty})
        all_imgs.append(annotation_data)

        if visualise:
            img = cv2.imread(annotation_data['filepath'])
            for bbox in annotation_data['bboxes']:
                cv2.rectangle(img, (bbox['x1'], bbox['y1']), (bbox['x2'], bbox['y2']), (0, 0, 255))
            cv2.imshow('img', img)
            print(annotation_data['imageset'])
            cv2.waitKey(0)
    print("Parse is done !")

    # Additional Settings
    if 'bg' not in classes_count:
        classes_count['bg'] = 0
        class_mapping['bg'] = len(class_mapping)
    random.shuffle(all_imgs)

    return all_imgs, classes_count, class_mapping


if __name__ == '__main__':
    all_imgs, classes_count, class_mapping = get_data(input_path=voc_input)
    print("실제로도 ... 총", len(all_imgs))
    print(len(all_imgs))
    pprint.pprint(classes_count)
    pprint.pprint(class_mapping)

'''
17125  files are on the annotation list. 
But, train :  5717 valid :  5823 are loaded
Total # data is  11540
실제로도 ... 총 11540
'''