import itertools
import cv2
import numpy as np
import random
from keras_frcnn import data_augment


class SampleSelector:
    def __init__(self, class_count):
        self.classes = [b for b in class_count.keys() if class_count[b] > 0]  # Remove zero samples
        self.class_cycle = itertools.cycle(self.classes)
        # Generate class_count's key - value iterator (val # not zeros)
        self.curr_class = next(self.class_cycle)

    def skip_sample_for_balanced_class(self, img_data):  # Remove bdd boxes which are zero samples.
        class_in_img = False
        for bbox in img_data['bboxes']:
            cls_name = bbox['class']
            if cls_name == self.curr_class:
                class_in_img = True
                self.curr_class = next(self.class_cycle)
                break

        if class_in_img:
            return False
        else:
            return True


def union(a_box, b_box):
    area_intersection = intersection(a_box, b_box)
    area_a = (a_box[2] - a_box[0]) * (a_box[3] - a_box[1])
    area_b = (b_box[2] - b_box[0]) * (b_box[3] - b_box[1])
    area_union = area_a + area_b - area_intersection
    return area_union


def intersection(a_box, b_box):
    x = max(a_box[0], b_box[0])
    y = max(a_box[1], b_box[1])
    w = min(a_box[2], b_box[2]) - x
    h = min(a_box[3], b_box[3]) - y
    if w < 0 or h < 0:
        return 0.0
    return w * h


def iou(a_box, b_box):
    if a_box[0] >= a_box[2] or a_box[1] >= a_box[3] or b_box[0] >= b_box[2] or b_box[1] >= b_box[3]:
        return 0.0
    area_i = intersection(a_box, b_box)
    area_u = union(a_box, b_box)
    return float(area_i) / float(area_u + 1e-6)


# image_rescale : with img_min_side (default 600)
def get_new_img_size(width, height, img_min_side=600):
    if width <= height:
        f = float(img_min_side) / width
        resized_height = int(f * height)
        resized_width = img_min_side
    else:
        f = float(img_min_side) / height
        resized_width = int(f * width)
        resized_height = img_min_side
    return resized_width, resized_height


def calc_rpn(configure, img_data, width, height, resized_width, resized_height, img_length_ft):
    downscale = float(configure.rpn_stride)  # default has 16
    anchor_sizes = configure.anchor_box_scales  # default has [128, 256, 512]
    anchor_ratios = configure.anchor_box_ratios  # default has [[1, 1], [1, 2], [2, 1]]
    num_anchors = len(anchor_sizes) * len(anchor_ratios)  # It turns out 9
    n_anchor_sizes = len(anchor_sizes)  # It turns out 3
    n_anchor_ratios = len(anchor_ratios)  # It turns out 3
    num_bboxes = len(img_data['bboxes'])
    # Inverted output_layer_shape of shared_network
    (output_width, output_height) = img_length_ft(resized_width, resized_height)

    y_rpn_overlap = np.zeros((output_height, output_width, num_anchors)).astype(int)
    y_is_box_valid = np.zeros((output_height, output_width, num_anchors)).astype(int)
    y_rpn_regression = np.zeros((output_height, output_width, 4 * num_anchors))

    num_anchors_for_bbox = np.zeros(num_bboxes).astype(int)
    best_anchor_for_bbox = -1 * np.ones((num_bboxes, 4)).astype(int)
    best_iou_for_bbox = np.zeros(num_bboxes).astype(np.float32)
    best_x_for_bbox = np.zeros((num_bboxes, 4))
    best_dx_for_bbox = np.zeros((num_bboxes, 4))

    # gta == ground truth box & we'll apply rescale
    gta = np.zeros((num_bboxes, 4))
    for bbox_idx, bbox in enumerate(img_data['bboxes']):
        gta[bbox_idx, 0] = bbox['x1'] * (resized_width / float(width))
        gta[bbox_idx, 1] = bbox['x2'] * (resized_width / float(width))
        gta[bbox_idx, 2] = bbox['y1'] * (resized_height / float(height))
        gta[bbox_idx, 3] = bbox['y2'] * (resized_height / float(height))

    # Pre-define anchor boxes
    for anchor_size_idx in range(n_anchor_sizes):
        for anchor_ratio_idx in range(n_anchor_ratios):
            anchor_x = anchor_sizes[anchor_size_idx] * anchor_ratios[anchor_ratio_idx][0]  # len of anchor_width
            anchor_y = anchor_sizes[anchor_size_idx] * anchor_ratios[anchor_ratio_idx][1]  # len of anchor_height

            for ix in range(output_width):  # sliding windows w.r.t. width
                x1_anc = downscale * (ix + 0.5) - anchor_x / 2
                x2_anc = downscale * (ix + 0.5) + anchor_x / 2
                if (x1_anc < 0) or (x2_anc > resized_width): continue

                for jy in range(output_height):  # sliding windows w.r.t. height
                    y1_anc = downscale * (jy + 0.5) - anchor_y / 2
                    y2_anc = downscale * (jy + 0.5) + anchor_y / 2
                    if (y1_anc < 0) or (y2_anc > resized_height): continue

                    # filter 'pos' or 'neg' and select Best IOUs w.r.t anchor boxes
                    bbox_type = 'neg'  # default neg (mostly, iou under 0.3)
                    best_iou_for_loc = 0.0
                    for bbox_idx in range(num_bboxes):
                        curr_iou = iou([gta[bbox_idx, 0], gta[bbox_idx, 2], gta[bbox_idx, 1], gta[bbox_idx, 3]],
                                       [x1_anc, y1_anc, x2_anc, y2_anc])
                        if curr_iou > best_iou_for_bbox[bbox_idx] or curr_iou > configure.rpn_max_overlap:
                            cx = (gta[bbox_idx, 0] + gta[bbox_idx, 1]) / 2.0  # x center of ground truth
                            cy = (gta[bbox_idx, 2] + gta[bbox_idx, 3]) / 2.0  # y center of ground truth
                            cxa = (x1_anc + x2_anc) / 2.0  # x center of anchor box
                            cya = (y1_anc + y2_anc) / 2.0  # y center of anchor box

                            tx = (cx - cxa) / (x2_anc - x1_anc)  # x difference of ratio between each center of two box
                            ty = (cy - cya) / (y2_anc - y1_anc)  # y difference of ratio between each center of two box
                            tw = 1.0 * (gta[bbox_idx, 1] - gta[bbox_idx, 0]) / (x2_anc - x1_anc)  # each width of boxes
                            th = 1.0 * (gta[bbox_idx, 3] - gta[bbox_idx, 2]) / (y2_anc - y1_anc)  # each height of boxes

                        if img_data['bboxes'][bbox_idx]['class'] != 'bg':  # save best iou
                            if curr_iou > best_iou_for_bbox[bbox_idx]:
                                best_anchor_for_bbox[bbox_idx] = [jy, ix, anchor_ratio_idx, anchor_size_idx]
                                best_iou_for_bbox[bbox_idx] = curr_iou
                                best_x_for_bbox[bbox_idx, :] = [x1_anc, x2_anc, y1_anc, y2_anc]
                                best_dx_for_bbox[bbox_idx, :] = [tx, ty, tw, th]

                            if curr_iou > configure.rpn_max_overlap:  # set pos if iou>0.5
                                bbox_type = 'pos'
                                num_anchors_for_bbox[bbox_idx] += 1
                                if curr_iou > best_iou_for_loc:
                                    best_iou_for_loc = curr_iou
                                    best_regression = (tx, ty, tw, th)

                            if configure.rpn_min_overlap < curr_iou < configure.rpn_max_overlap:  # set neutral(ambiguous)
                                if bbox_type != 'pos':
                                    bbox_type = 'neutral'

                    if bbox_type == 'neg':  # anchor_ratio_idx + n_anchor_ratios * anchor_size_idx : 0 ~ 8 anchors
                        y_is_box_valid[jy, ix, anchor_ratio_idx + n_anchor_ratios * anchor_size_idx] = 1
                        y_rpn_overlap[jy, ix, anchor_ratio_idx + n_anchor_ratios * anchor_size_idx] = 0

                    elif bbox_type == 'neutral':
                        y_is_box_valid[jy, ix, anchor_ratio_idx + n_anchor_ratios * anchor_size_idx] = 0
                        y_rpn_overlap[jy, ix, anchor_ratio_idx + n_anchor_ratios * anchor_size_idx] = 0

                    elif bbox_type == 'pos':
                        y_is_box_valid[jy, ix, anchor_ratio_idx + n_anchor_ratios * anchor_size_idx] = 1
                        y_rpn_overlap[jy, ix, anchor_ratio_idx + n_anchor_ratios * anchor_size_idx] = 1
                        start = 4 * (anchor_ratio_idx + n_anchor_ratios * anchor_size_idx)
                        y_rpn_regression[jy, ix, start: start + 2] = best_regression[0:2]
                        y_rpn_regression[jy, ix, start + 2: start + 4] = np.log(best_regression[2:])

    for idx in range(num_anchors_for_bbox.shape[0]):  # additional positive conditions (relative maximum value)
        if num_anchors_for_bbox[idx] == 0:
            if best_anchor_for_bbox[idx, 0] == -1: continue  # because initialized by -1 i.e. not update!
            y_is_box_valid[best_anchor_for_bbox[idx, 0], best_anchor_for_bbox[idx, 1],
                           best_anchor_for_bbox[idx, 2] + n_anchor_ratios * best_anchor_for_bbox[idx, 3]] = 1
            y_rpn_overlap[best_anchor_for_bbox[idx, 0], best_anchor_for_bbox[idx, 1],
                          best_anchor_for_bbox[idx, 2] + n_anchor_ratios * best_anchor_for_bbox[idx, 3]] = 1
            start = 4 * (best_anchor_for_bbox[idx, 2] + n_anchor_ratios * best_anchor_for_bbox[idx, 3])
            y_rpn_regression[best_anchor_for_bbox[idx, 0], best_anchor_for_bbox[idx, 1], start: start + 2] = best_dx_for_bbox[idx, 0:2]
            y_rpn_regression[best_anchor_for_bbox[idx, 0], best_anchor_for_bbox[idx, 1], start + 2: start + 4] = np.log(best_dx_for_bbox[idx, 2:4])

    y_rpn_overlap = np.transpose(y_rpn_overlap, (2, 0, 1))
    y_rpn_overlap = np.expand_dims(y_rpn_overlap, axis=0)
    y_is_box_valid = np.transpose(y_is_box_valid, (2, 0, 1))
    y_is_box_valid = np.expand_dims(y_is_box_valid, axis=0)
    y_rpn_regression = np.transpose(y_rpn_regression, (2, 0, 1))
    y_rpn_regression = np.expand_dims(y_rpn_regression, axis=0)

    pos_locs = np.where(np.logical_and(y_rpn_overlap[0, :, :, :] == 1, y_is_box_valid[0, :, :, :] == 1))
    neg_locs = np.where(np.logical_and(y_rpn_overlap[0, :, :, :] == 0, y_is_box_valid[0, :, :, :] == 1))

    num_pos = len(pos_locs[0])

    # select 256 positive anchor samples
    num_regions = 256
    if len(pos_locs[0]) > num_regions / 2:
        val_locs = random.sample(range(len(pos_locs[0])), len(pos_locs[0]) - num_regions / 2)
        y_is_box_valid[0, pos_locs[0][val_locs], pos_locs[1][val_locs], pos_locs[2][val_locs]] = 0
        num_pos = num_regions / 2

    if len(neg_locs[0]) + num_pos > num_regions:
        val_locs = random.sample(range(len(neg_locs[0])), len(neg_locs[0]) - num_pos)
        y_is_box_valid[0, neg_locs[0][val_locs], neg_locs[1][val_locs], neg_locs[2][val_locs]] = 0

    y_rpn_classifier = np.concatenate([y_is_box_valid, y_rpn_overlap], axis=1)
    y_rpn_regressor = np.concatenate([np.repeat(y_rpn_overlap, 4, axis=1), y_rpn_regression], axis=1)
    return np.copy(y_rpn_classifier), np.copy(y_rpn_regressor)  # returns : (1, 18, w, h) , (1, 72, w, h)


def get_gt_anchor(all_img_data, class_count, configure, img_length_ft, backend, mode='train'):
    sample_selector = SampleSelector(class_count=class_count)
    while True:
        for img_data in all_img_data:
            try:
                if configure.balanced_classes and sample_selector.skip_sample_for_balanced_class(img_data): continue
                if mode == 'train':
                    img_data_aug, x_img = data_augment.augment(img_data, configure, augment_mode=True)
                else:
                    img_data_aug, x_img = data_augment.augment(img_data, configure, augment_mode=False)

                (width, height) = (img_data_aug['width'], img_data_aug['height'])
                (rows, cols, _) = x_img.shape

                (resized_width, resized_height) = get_new_img_size(width, height, configure.im_size)
                x_img = cv2.resize(x_img, (resized_width, resized_height), interpolation=cv2.INTER_CUBIC)

                try:
                    y_rpn_classifier, y_rpn_regressor = calc_rpn(configure, img_data_aug, width, height, resized_width,
                                                                 resized_height, img_length_ft)
                except:
                    continue

                x_img = x_img[:, :, (2, 1, 0)]  # BGR to RGB
                x_img = x_img.astype(np.float32)
                x_img[:, :, 0] -= configure.img_channel_mean[0]
                x_img[:, :, 1] -= configure.img_channel_mean[1]
                x_img[:, :, 2] -= configure.img_channel_mean[2]
                x_img /= configure.img_scaling_factor  # standardization

                x_img = np.transpose(x_img, (2, 0, 1))
                x_img = np.expand_dims(x_img, axis=0)  # RGB to [1, c, w, h]

                # scaling only a part of rpn_box_valid
                y_rpn_regressor[:, y_rpn_regressor.shape[1] // 2:, :, :] *= configure.std_scaling

                if backend == 'channels_last':
                    x_img = np.transpose(x_img, (0, 2, 3, 1))  # [1, w, h, c]
                    y_rpn_classifier = np.transpose(y_rpn_classifier, (0, 2, 3, 1))  # [1, w, h, 18]
                    y_rpn_regressor = np.transpose(y_rpn_regressor, (0, 2, 3, 1))  # [1, w, h, 72]
                yield np.copy(x_img), [np.copy(y_rpn_classifier).astype('float32'),
                                       np.copy(y_rpn_regressor)], img_data_aug

            except Exception as e:
                print(e)
                continue
